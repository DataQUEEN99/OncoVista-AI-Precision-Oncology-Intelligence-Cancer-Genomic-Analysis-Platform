import express from "express";
import path from "path";
import fs from "fs";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

// Parse incoming payloads
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Lazy initializer for Gemini Gen AI
let aiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key && key !== "MY_GEMINI_API_KEY" && key.trim() !== "") {
      aiClient = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
  }
  return aiClient;
}

// Global In-Memory Genomic Database
interface PatientMutation {
  gene: string;
  variant: string;
  consequence: string;
  vaf: number; // Variant Allele Frequency
  depth: number;
  pathogenicity: "Pathogenic" | "Likely Pathogenic" | "VUS" | "Benign";
  clinicalSignificance: string;
}

interface Patient {
  id: string;
  name: string;
  age: number;
  gender: string;
  diagnosis: string;
  stage: string;
  status: "Active" | "Stable" | "Progression" | "Remission";
  tumorBurden: number; // Mutations per Megabase
  mutations: PatientMutation[];
  riskScore: number; // 0-100%
  riskClassification: "High" | "Intermediate" | "Low";
  createdAt: string;
}

// Initial Simulated Oncology Patients
const patientDatabase: Patient[] = [
  {
    id: "PT-701A",
    name: "Dr. Evelyn Cartwright",
    age: 62,
    gender: "Female",
    diagnosis: "Lung Adenocarcinoma (LUAD)",
    stage: "Stage IV",
    status: "Active",
    tumorBurden: 12.4,
    mutations: [
      {
        gene: "EGFR",
        variant: "L858R",
        consequence: "Missense",
        vaf: 0.42,
        depth: 820,
        pathogenicity: "Pathogenic",
        clinicalSignificance: "Sensitizes to first and third-generation EGFR inhibitors like Osimertinib.",
      },
      {
        gene: "TP53",
        variant: "R273H",
        consequence: "Missense",
        vaf: 0.38,
        depth: 760,
        pathogenicity: "Pathogenic",
        clinicalSignificance: "Loss of tumor suppressor function. Associated with chemotherapy resistance & higher aggression.",
      },
      {
        gene: "PIK3CA",
        variant: "E545K",
        consequence: "Missense",
        vaf: 0.15,
        depth: 450,
        pathogenicity: "Pathogenic",
        clinicalSignificance: "Activating PI3K path change. Suggestive of resistance to EGFR mono-therapy; targetable by Piqray.",
      }
    ],
    riskScore: 78,
    riskClassification: "High",
    createdAt: "2026-03-12T14:24:00Z"
  },
  {
    id: "PT-892B",
    name: "Marcus Vance",
    age: 47,
    gender: "Male",
    diagnosis: "Colorectal Adenocarcinoma (COAD)",
    stage: "Stage III",
    status: "Stable",
    tumorBurden: 24.1,
    mutations: [
      {
        gene: "KRAS",
        variant: "G12D",
        consequence: "Missense",
        vaf: 0.48,
        depth: 980,
        pathogenicity: "Pathogenic",
        clinicalSignificance: "Precludes anti-EGFR antibody therapies (Cetuximab). Activates downstream MAPK transduction cascade.",
      },
      {
        gene: "APC",
        variant: "R1450*",
        consequence: "Nonsense (Stopgain)",
        vaf: 0.51,
        depth: 1100,
        pathogenicity: "Pathogenic",
        clinicalSignificance: "Truncating mutation in Wnt pathway regulator APC, initiating hyperproliferation.",
      }
    ],
    riskScore: 65,
    riskClassification: "Intermediate",
    createdAt: "2026-04-05T09:15:00Z"
  },
  {
    id: "PT-234C",
    name: "Elena Rostova",
    age: 39,
    gender: "Female",
    diagnosis: "Breast Infiltrating Carcinoma (BRCA)",
    stage: "Stage II",
    status: "Remission",
    tumorBurden: 4.2,
    mutations: [
      {
        gene: "BRCA1",
        variant: "C61G",
        consequence: "Missense / Zinc Finger disruption",
        vaf: 0.49,
        depth: 1240,
        pathogenicity: "Pathogenic",
        clinicalSignificance: "Germline genomic risk marker. Deficient homologous recombination DNA repair processes. Highly sensitive to PARP inhibitors (e.g., Olaparib).",
      }
    ],
    riskScore: 32,
    riskClassification: "Low",
    createdAt: "2026-05-01T11:00:00Z"
  },
  {
    id: "PT-551D",
    name: "Kenji Sato",
    age: 55,
    gender: "Male",
    diagnosis: "Cutaneous Melanoma (SKCM)",
    stage: "Stage IV",
    status: "Progression",
    tumorBurden: 31.8,
    mutations: [
      {
        gene: "BRAF",
        variant: "V600E",
        consequence: "Missense",
        vaf: 0.55,
        depth: 630,
        pathogenicity: "Pathogenic",
        clinicalSignificance: "Strongly sensitizes to BRAF/MEK combo inhibitors (Vemurafenib/Cobimetinib). Highly proliferative target.",
      },
      {
        gene: "NF1",
        variant: "Q1341*",
        consequence: "Nonsense",
        vaf: 0.28,
        depth: 540,
        pathogenicity: "Pathogenic",
        clinicalSignificance: "Loss of negative RAS feedback control, leading to potential dual RAF-MEK inhibitor resistance bypass."
      }
    ],
    riskScore: 92,
    riskClassification: "High",
    createdAt: "2026-05-18T16:40:00Z"
  }
];

// Curated Oncology Biomarkers and targeted matches
const curatedBiomarkers = [
  { gene: "EGFR", mutation: "L858R / Exon 19 del", agent: "Osimertinib / Gefitinib", tier: "Tier IA (FDA)", response: "Sensitive", evidence: "FLAURA Phase III Trial" },
  { gene: "EGFR", mutation: "T790M", agent: "Osimertinib", tier: "Tier IA (FDA)", response: "Sensitive (Override Resistance)", evidence: "AURA3 Trials" },
  { gene: "BRAF", mutation: "V600E", agent: "Dabrafenib + Trametinib", tier: "Tier IA (FDA)", response: "Highly Sensitive", evidence: "COMBI-d Phase III" },
  { gene: "BRCA1", mutation: "Homologous Recombination Defect", agent: "Olaparib / Talazoparib", tier: "Tier IA (FDA)", response: "Sensitive", evidence: "OlimpiAD Phase III study" },
  { gene: "KRAS", mutation: "G12C", agent: "Sotorasib / Adagrasib", tier: "Tier IB (NCCN)", response: "Sensitive", evidence: "CodeBreaK 200 Trial" },
  { gene: "KRAS", mutation: "G12D / G12V", agent: "Anti-EGFR contraindicated", tier: "Tier IIC (Clinical Evidence)", response: "Resistance to Cetuximab", evidence: "TAILOR and PRIME analysis" },
  { gene: "TP53", mutation: "Any pathogenic truncating", agent: "WEE1 Inhibitors / Ad-p53 gene therapy", tier: "Tier III (Clinical Trial)", response: "Investigational Sensitization", evidence: "Ongoing Phase I/II validation" },
  { gene: "ALK", mutation: "EML4-ALK Fusion", agent: "Alectinib / Lorlatinib", tier: "Tier IA (FDA)", response: "Exceptional Response", evidence: "ALEX Trial" }
];

// TCGA Mutational Frequency Cohort representation
const tcgaCohorts = {
  LUAD: { name: "Lung Adenocarcinoma", sampleCount: 512, driverFreqs: [{ gene: "TP53", pct: 45 }, { gene: "EGFR", pct: 15 }, { gene: "KRAS", pct: 28 }, { gene: "ALK", pct: 5 }, { gene: "BRAF", pct: 4 }] },
  COAD: { name: "Colorectal Adenocarcinoma", sampleCount: 418, driverFreqs: [{ gene: "TP53", pct: 60 }, { gene: "APC", pct: 81 }, { gene: "KRAS", pct: 43 }, { gene: "PIK3CA", pct: 18 }, { gene: "BRAF", pct: 7 }] },
  BRCA: { name: "Breast Infiltrating Carcinoma", sampleCount: 1044, driverFreqs: [{ gene: "TP53", pct: 33 }, { gene: "PIK3CA", pct: 35 }, { gene: "BRCA1", pct: 6 }, { gene: "BRCA2", pct: 5 }, { gene: "GATA3", pct: 12 }] },
  SKCM: { name: "Skin Cutaneous Melanoma", sampleCount: 468, driverFreqs: [{ gene: "BRAF", pct: 52 }, { gene: "NRAS", pct: 24 }, { gene: "TP53", pct: 18 }, { gene: "NF1", pct: 13 }, { gene: "CDKN2A", pct: 14 }] },
};

// --- AUTHENTICATION API ROCKS (JWT Mock / Clinician Session) ---
app.post("/api/auth/register", (req, res) => {
  const { email, password, name, role } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "Missing required registration parameters." });
  }
  return res.json({
    success: true,
    user: { email, name: name || "Genomics Specialist", role: role || "Clinician" },
    token: `oncocore-jwt-token-sim-${Math.random().toString(36).substr(2)}`
  });
});

app.post("/api/auth/login", (req, res) => {
  const { email, password, role } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "Missing login credentials." });
  }
  // Standard futuristic developer friendly authentication bypass/fallback
  const defaultUser = {
    email,
    name: email.split("@")[0].charAt(0).toUpperCase() + email.split("@")[0].slice(1),
    role: role || "Clinician"
  };
  return res.json({
    success: true,
    user: defaultUser,
    token: "oncovista-ai-secure-jwt-key"
  });
});

// --- PATIENT genomics API ---
app.get("/api/patients", (req, res) => {
  res.json(patientDatabase);
});

app.get("/api/patients/:id", (req, res) => {
  const patient = patientDatabase.find(p => p.id === req.params.id);
  if (!patient) {
    return res.status(404).json({ error: "Patient cohort not found in core workspace database." });
  }
  res.json(patient);
});

app.post("/api/patients", (req, res) => {
  const { name, age, gender, diagnosis, stage, status, mutations, tumorBurden } = req.body;
  
  if (!name || !diagnosis) {
    return res.status(400).json({ error: "Missing patient name or clinical diagnosis." });
  }

  // Calculate simulated tumor risk aggregates
  let riskVal = 30;
  if (stage.includes("IV") || stage.includes("4")) riskVal += 40;
  else if (stage.includes("III") || stage.includes("3")) riskVal += 25;
  if (parseFloat(tumorBurden) > 15) riskVal += 15;
  if (mutations && mutations.some((m: any) => ["TP53", "KRAS"].includes(m.gene.toUpperCase()))) riskVal += 15;
  riskVal = Math.min(riskVal, 98);

  const riskClass = riskVal > 75 ? "High" : riskVal > 45 ? "Intermediate" : "Low";

  const newPatient: Patient = {
    id: `PT-${Math.floor(100 + Math.random() * 900)}${String.fromCharCode(65 + Math.floor(Math.random() * 26))}`,
    name,
    age: parseInt(age) || 50,
    gender: gender || "Other",
    diagnosis,
    stage: stage || "Stage II",
    status: status || "Active",
    tumorBurden: parseFloat(tumorBurden) || 6.1,
    mutations: mutations || [],
    riskScore: riskVal,
    riskClassification: riskClass,
    createdAt: new Date().toISOString()
  };

  patientDatabase.unshift(newPatient);
  res.status(201).json(newPatient);
});

// --- MUTATION PARSING ENGINE (CSV & VCF Parser simulation) ---
app.post("/api/mutations/upload", (req, res) => {
  const { fileName, fileContent, patientId } = req.body;
  if (!fileContent) {
    return res.status(400).json({ error: "No configuration code or genomic content provided." });
  }

  // Real parsing emulator that decodes VCF header tags or simple comma mutations
  const parsedMutations: PatientMutation[] = [];
  const lines = fileContent.split("\n");

  try {
    if (fileName && fileName.endsWith(".vcf")) {
      // VCF Parser
      let mutationCount = 0;
      for (const line of lines) {
        if (line.startsWith("#")) continue; // Skip header tags
        const parts = line.split("\t");
        if (parts.length >= 5) {
          const chrome = parts[0];
          const pos = parts[1];
          const info = parts[7] || "";
          
          let gene = "UNKNOWN";
          if (info.includes("GENE=")) {
            gene = info.split("GENE=")[1].split(";")[0];
          } else {
            // Pick a likely driver gene from position or random mapping
            const sampleDrivers = ["TP53", "EGFR", "KRAS", "BRCA1", "PIK3CA", "BRAF"];
            gene = sampleDrivers[mutationCount % sampleDrivers.length];
          }

          const ref = parts[3];
          const alt = parts[4];
          
          parsedMutations.push({
            gene,
            variant: `g.${chrome}:pos${pos}${ref}>${alt}`,
            consequence: "Missense substitution",
            vaf: parseFloat((0.15 + (Math.random() * 0.45)).toFixed(3)),
            depth: Math.floor(400 + Math.random() * 800),
            pathogenicity: mutationCount % 3 === 0 ? "Pathogenic" : "Likely Pathogenic",
            clinicalSignificance: `Detected alt mutation ${ref} to ${alt} in critical codon element.`
          });
          mutationCount++;
          if (mutationCount >= 8) break; // Keep payload balanced
        }
      }
    } else {
      // CSV/TSV parser model
      let isHeader = true;
      for (const line of lines) {
        if (!line.trim()) continue;
        if (isHeader) {
          isHeader = false;
          continue;
        }
        const cols = line.split(",");
        if (cols.length >= 2) {
          const gene = cols[0].replace(/"/g, "").trim().toUpperCase();
          const variant = cols[1].replace(/"/g, "").trim();
          const pathogenicity = (cols[2] || "Pathogenic").replace(/"/g, "").trim() as any;
          const significance = cols[3] || "Clinically relevant oncogenic driver mutation";
          
          parsedMutations.push({
            gene,
            variant,
            consequence: "Missense Mutation",
            vaf: 0.35,
            depth: 852,
            pathogenicity,
            clinicalSignificance: significance
          });
        }
      }
    }

    // Default if parsing yields nothing
    if (parsedMutations.length === 0) {
      parsedMutations.push(
        { gene: "TP53", variant: "C238Y", consequence: "Missense", vaf: 0.44, depth: 950, pathogenicity: "Pathogenic", clinicalSignificance: "DNA binding domain perturbation." },
        { gene: "EGFR", variant: "T790M", consequence: "Missense", vaf: 0.22, depth: 680, pathogenicity: "Pathogenic", clinicalSignificance: "Gatekeeper mutation causing resistance." }
      );
    }

    // If active patient ID, inject mutations
    if (patientId) {
      const patient = patientDatabase.find(p => p.id === patientId);
      if (patient) {
        patient.mutations = [...patient.mutations, ...parsedMutations];
        patient.tumorBurden += parseFloat((parsedMutations.length * 1.5).toFixed(1));
        patient.riskScore = Math.min(patient.riskScore + 10, 96);
        return res.json({
          success: true,
          message: `Genomic alignment completed. Injected ${parsedMutations.length} mutations to ${patient.name}.`,
          patient
        });
      }
    }

    return res.json({
      success: true,
      message: `Genomic alignment completed. Found ${parsedMutations.length} mutations ready for diagnostic matching.`,
      mutations: parsedMutations
    });

  } catch (err: any) {
    return res.status(500).json({ error: `Genomic Alignment Engine failed: ${err.message}` });
  }
});

// --- BIOMARKER DATABASE ---
app.get("/api/biomarkers", (req, res) => {
  res.json(curatedBiomarkers);
});

// --- CANCER COHORTS ---
app.get("/api/cohorts", (req, res) => {
  res.json(tcgaCohorts);
});

// --- CLINICAL SURVIVAL SIMULATION (TCGA KAPLAN-MEIER & CLINICAL CORRELATION) ---
app.get("/api/survival-plot", (req, res) => {
  const { diagnosis, mutationGroup } = req.query;
  
  // Generates 15 data intervals for Kaplan-Meier analysis displaying percentage of survival
  const generateKMCurve = (hazardRatio: number) => {
    let survivals = [];
    let currentSurvival = 100;
    for (let month = 0; month <= 60; month += 4) {
      const dropChance = (0.015 * hazardRatio) + (Math.sin(month / 10) * 0.005);
      currentSurvival = currentSurvival * (1 - Math.max(0.002, dropChance));
      survivals.push({
        month,
        survivalPct: parseFloat(Math.max(2, currentSurvival).toFixed(1))
      });
    }
    return survivals;
  };

  const isMutated = mutationGroup === "mutated";
  const hazardFactor = isMutated ? 1.68 : 0.95;

  return res.json({
    cohort: diagnosis || "All Cohorts",
    mutationGroup: mutationGroup || "Wild-type",
    medianSurvivalMonths: isMutated ? 22 : 48,
    hazardRatio: isMutated ? 1.84 : 1.0,
    survivalData: generateKMCurve(hazardFactor)
  });
});

// --- TUMOR EVOLUTION INTELLIGENCE ENGINE ---
app.get("/api/evolution/simulate", (req, res) => {
  const { patientId, treatmentTrigger } = req.query;
  
  // Simulated clonal evolution node hierarchy
  // Under treatment selection pressure, clonal genotypes dynamically change
  const defaultEvolution = {
    timelineWeeks: [0, 4, 12, 24],
    treatmentPressure: treatmentTrigger || "Osimertinib 80mg clinical regimen",
    clonalPhases: [
      {
        timepoint: "Pre-Treatment (Week 0)",
        clones: [
          { name: "Founder Clone (C0)", fraction: 100, mutations: ["APC Loss of Function", "EGFR L858R"], sensitivity: "Highly sensitive" },
          { name: "Subclone A (C1)", fraction: 15, mutations: ["TP53 Mutation mutation"], sensitivity: "Moderately sensitive" }
        ],
        clonalMetastasisChance: "2% (Negligible)"
      },
      {
        timepoint: "Induction therapy (Week 4)",
        clones: [
          { name: "Founder Clone (C0)", fraction: 35, mutations: ["APC Loss of Function", "EGFR L858R"], sensitivity: "Responding visual reduction" },
          { name: "Subclone A (C1)", fraction: 22, mutations: ["TP53 Mutation mutation"], sensitivity: "Slight expansion rate" },
          { name: "Resistant Driver Subclone (C2)", fraction: 4, mutations: ["EGFR T790M Gatekeeper", "TP53"], sensitivity: "Absolute resistance initialized" }
        ],
        clonalMetastasisChance: "8% (Low)"
      },
      {
        timepoint: "Consolidation (Week 12)",
        clones: [
          { name: "Founder Clone (C0)", fraction: 8, mutations: ["APC Loss of Function", "EGFR L858R"], sensitivity: "Nearing systemic ablation" },
          { name: "Subclone A (C1)", fraction: 12, mutations: ["TP53 Mutation mutation"], sensitivity: "Dormant persistence" },
          { name: "Resistant Driver Subclone (C2)", fraction: 48, mutations: ["EGFR T790M Gatekeeper", "TP53"], sensitivity: "Highly active expansion under Osimertinib selective survival" }
        ],
        clonalMetastasisChance: "35% (Moderate)"
      },
      {
        timepoint: "Clinical Recurrence Progression (Week 24)",
        clones: [
          { name: "Founder Clone (C0)", fraction: 2, mutations: ["APC Loss of Function", "EGFR L858R"], sensitivity: "Residual trace" },
          { name: "Subclone A (C1)", fraction: 8, mutations: ["TP53 Mutation mutation"], sensitivity: "Indolent fraction" },
          { name: "Resistant Driver Subclone (C2)", fraction: 88, mutations: ["EGFR T790M Gatekeeper", "TP53"], sensitivity: "Dominant tumor lineage. Clinical intervention switch required." }
        ],
        clonalMetastasisChance: "72% (High Risk - Lung / Bone tracking suggested)"
      }
    ],
    metastaticProjections: [
      { organ: "Pleural Effusion", probability: 68 },
      { organ: "Osteolytic Bone Lesions", probability: 42 },
      { organ: "Brain Ventricular System", probability: 25 },
      { organ: "Hepatic Margins", probability: 15 }
    ]
  };

  res.json(defaultEvolution);
});

// --- ADVANCED AI MOLECULAR TUMOR BOARD & INTERPRETATION (Server-Side Gemini API) ---
app.post("/api/gemini/interpret", async (req, res) => {
  const { gene, variant, patientContext } = req.body;
  if (!gene) {
    return res.status(400).json({ error: "Missing Target Gene for AI validation." });
  }

  const ai = getGenAI();

  const queryPrompt = `
    Conduct an expert molecular tumor board interpretation for:
    Gene: ${gene}
    Variant: ${variant || "Unspecified exon codon variance"}
    Patient Demographics / Context: ${patientContext || "Patient diagnosed with advanced active malignant neoplasm."}

    Provide clinical interpretation following this exact structured format in raw JSON (no nested arrays, plain properties):
    {
      "pathogenicity": "Pathogenic / Likely Pathogenic / VUS / Benign",
      "mechanism": "Paragraph describing molecular mechanism of the mutation, its biochemical impact, downstream pathway effect (e.g. MAPK/AKT signaling pathway overactivation).",
      "targetedTherapies": "List of FDA-approved targeted inhibitors or immunotherapies matching this alteration.",
      "resistanceMarkers": "Potential clinical resistance bypass factors (e.g., secondary gatekeeper mutations).",
      "clinicalTrialSuggestion": "Description of ongoing Clinical Trial concepts (e.g. phase, agent target).",
      "prognosticImpact": "Short paragraph analyzing the hazard ratio/survival implication of this mutation over standard driver lines.",
      "tumorBoardRecommendation": "Step by step clinical recommendations for the oncology medical team."
    }
  `;

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: queryPrompt,
        config: {
          responseMimeType: "application/json"
        }
      });
      
      const cleanText = response.text || "{}";
      const parsed = JSON.parse(cleanText.trim());
      return res.json({ aiGenerated: true, analysis: parsed });
    } catch (err: any) {
      console.error("Gemini oncology interpretation error, resolving with fallback:", err);
      // Fallback response with beautiful clinical diagnostics
      return res.json({
        aiGenerated: false,
        warning: "Gemini server-side active connection fell back to integrated biotech parser.",
        analysis: getIntegratedAnalysisFeedback(gene, variant)
      });
    }
  } else {
    // Return standard premium bioinformatics database recommendations when API key not configured yet
    return res.json({
      aiGenerated: false,
      warning: "OncoVista local genomics core database responding (Gemini key not configured).",
      analysis: getIntegratedAnalysisFeedback(gene, variant)
    });
  }
});

// Formal oncology diagnostic reporting mechanism
app.post("/api/reports/generate-clinical", async (req, res) => {
  const { patientId, doctorNotes, selectionList } = req.body;
  const patient = patientDatabase.find(p => p.id === patientId);

  if (!patient) {
    return res.status(404).json({ error: "Active patient record not parsed." });
  }

  const ai = getGenAI();
  if (ai) {
    try {
      const queryPrompt = `
        Draft a formal clinical consultation report for the Molecular Tumor Board of OncoVista AI.
        Patient Name: ${patient.name}
        Age/Sex: ${patient.age} / ${patient.gender}
        Diagnosis: ${patient.diagnosis} (${patient.stage})
        Mutational Burden: ${patient.tumorBurden} mut/Mb (Risk: ${patient.riskClassification})
        Identified Alterations: ${patient.mutations.map(m => `${m.gene} ${m.variant} (${m.pathogenicity})`).join(", ")}
        Oncologist Notes: ${doctorNotes || "General therapy recommendation requested."}

        Provide structured clinical text in JSON format (do not return raw Markdown outside the JSON):
        {
          "summary": "Executive summary of patient case genomics.",
          "molecularPathologicalSynthesis": "Synthesis of the driver mutations and co-mutation environment.",
          "suggestedTherapyRegimen": "Recommended pharmacological pipeline (FDA targets & Immunotherapy).",
          "resistanceMitigation": "Strategic approaches to prevent clonal divergence & resistant bypasses.",
          "personalizedClinicalTrialSummary": "Matched active trials based on the patient profile."
        }
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: queryPrompt,
        config: {
          responseMimeType: "application/json"
        }
      });

      const parsed = JSON.parse(response.text?.trim() || "{}");
      return res.json({
        success: true,
        patient,
        aiGenerated: true,
        report: parsed,
        timestamp: new Date().toISOString()
      });

    } catch (err) {
      console.error("AI Clinical report failed, serving structured system compilation:", err);
    }
  }

  // Pure deterministic clinical assembler if AI key missing or errors
  return res.json({
    success: true,
    patient,
    aiGenerated: false,
    report: {
      summary: `OncoVista molecular tumor panel detected highly active alterations in ${patient.mutations.map(m => m.gene).join(" & ")}. Diagnostic testing indicates ${patient.riskClassification} progression risk requiring tailored molecular treatment.`,
      molecularPathologicalSynthesis: `Co-mutational dynamics are driven heavily by ${patient.stage} classification. The mutation load level of ${patient.tumorBurden} mut/Mb correlates with modern clinical phenotypes.`,
      suggestedTherapyRegimen: `Based on patient sequencing, key targeted agents include ${patient.mutations.map(m => m.gene === "EGFR" ? "Osimertinib" : m.gene === "BRAF" ? "Dabrafenib/Trametinib" : m.gene === "BRCA1" ? "Olaparib" : "Mechanistic target-directed inhibitors").join(" or ")}.`,
      resistanceMitigation: "Strict imaging followup every 6-8 weeks is indicated. Clonal resistance monitoring via circulating tumor DNA (ctDNA) liquid biopsy can locate resistance mutations earlier.",
      personalizedClinicalTrialSummary: `Initiating enrollment review for genomic-adaptive basket trials matching mutated signature codes (e.g. NCT-OncoMATCH protocols).`
    },
    timestamp: new Date().toISOString()
  });
});

// Helper library for high-fidelity fallback diagnostic database responses
function getIntegratedAnalysisFeedback(gene: string, variant: string) {
  const normalizedGene = gene.toUpperCase().trim();
  
  const library: Record<string, any> = {
    TP53: {
      pathogenicity: "Pathogenic",
      mechanism: "Disruption of physical structural stability inside zinc-binding structural residues, abolishing sequence-specific DNA transcription control and enabling persistent anti-apoptosis checkpoints.",
      targetedTherapies: "Investigational WEE1 kinase inhibitors (Adavosertib), synthetic APR-246 reactivation agents, and standard platinum doublet therapies to maximize genetic fragmentation.",
      resistanceMarkers: "Multidrug resistance transporter MDR1 upregulation. Precludes rapid single-agent clearance.",
      clinicalTrialSuggestion: "NCT04116541: Targeted Phase II trials pairing APR-246 with systemic immunotherapy inhibitors.",
      prognosticImpact: "Hazard Ratio of 2.14 in TCGA clinical cohorts. Associated with significantly shorter progression-free survival intervals.",
      tumorBoardRecommendation: "Examine baseline cardiac fractions. Avoid single-agent therapies; incorporate sequential combination therapy targeting alternative active kinetic kinases."
    },
    EGFR: {
      pathogenicity: "Pathogenic",
      mechanism: "Exon 21 point mutation or Exon 19 deletions cause continuous ATP cleft hyperactivation without normal ligand gating, feeding continuous downstream mitogenic cellular signaling.",
      targetedTherapies: "Osimertinib (Third-generation irreversible tyrosine kinase inhibitor), Gefitinib, Erlotinib.",
      resistanceMarkers: "Secondary 'Gatekeeper' mutation EGFR T790M (blocking drug binding) or tertiary C797S mutations.",
      clinicalTrialSuggestion: "FLAURA2 clinical program: assessment of first-line Osimertinib combined with intensive chemotherapy cycles.",
      prognosticImpact: "Highly prognostic diagnostic driver. Strongly associated with rapid treatment response but requires active evasion followup.",
      tumorBoardRecommendation: "Prescribe Osimertinib 80mg daily. Perform plasma cell-free DNA (liquid biopsy) checks at month 3 and 6 to locate therapeutic resistance early."
    },
    BRCA1: {
      pathogenicity: "Pathogenic",
      mechanism: "Deleterious mutation within DNA damage sensing zinc RING domain or BRCT repeats, leading to double-stranded DNA homologous recombination repair (HRD) failure.",
      targetedTherapies: "PARP Inhibitors (Olaparib, Talazoparib, Rucaparib). Highly sensitive to Platinum agents.",
      resistanceMarkers: "Reversion mutations in BRCA1 open reading frame restoring active protein synthesis.",
      clinicalTrialSuggestion: "NCT03212398: Evaluation of Olaparib alongside anti-PD-L1 checkpoint inhibitors.",
      prognosticImpact: "High germline clinical risk; predicts profound sensitivity to targeted genomic-repair cell cycle arrest therapies.",
      tumorBoardRecommendation: "Recommend Olaparib therapy. Consider genetic counseling referral for active family lineage germline screening guidance."
    },
    KRAS: {
      pathogenicity: "Pathogenic",
      mechanism: "Locks the G-domain active switch in continuous GTP-bound state, continuously overstimulating the downstream RAF-MEK-ERK signaling grid independent of upstream receptor status.",
      targetedTherapies: "Sotorasib / Adagrasib (custom targeted G12C covalent inhibitors). KRAS G12D customized immunotherapies.",
      resistanceMarkers: "Secondary mutation evolution at codon 12/61 or secondary bypass loops overexpressing MET receptor.",
      clinicalTrialSuggestion: "CodeBreaK-300: Phase III randomized evaluation of trial matches combined with therapeutic antibodies.",
      prognosticImpact: "Severely prognostic: precludes clinical Cetuximab or Panitumumab efficacy in colorectal oncology.",
      tumorBoardRecommendation: "Strict avoidance of EGFR-targeted antibody monotherapy. Sequence G12C directed agents if mutated, otherwise explore combined MEK/PI3K trial pipelines."
    }
  };

  return library[normalizedGene] || {
    pathogenicity: "VUS (Variant of Uncertain Significance)",
    mechanism: `Genomic codon shift located in ${normalizedGene} protein domain. Structural downstream kinetic influence is currently under computational research.`,
    targetedTherapies: "None FDA-approved specifically for this low-frequency variant. Off-label matching guided by full co-mutational status.",
    resistanceMarkers: "No active resistance mechanism recorded in Clinical interpretation files.",
    clinicalTrialSuggestion: "NCT-BasketMatch: Genomic match trials recruiting rare, unclassified cohort variations.",
    prognosticImpact: "Neutral or marginally favorable; no significant change from cohort baseline metrics.",
    tumorBoardRecommendation: "Continue sequencing monitoring. Focus clinical therapeutic choice on primary drivers (e.g. TP53 structural alterations or clinical staging guidance)."
  };
}

// Vite and Static assets router binding
const isProd = process.env.NODE_ENV === "production";

async function runApplication() {
  if (!isProd) {
    // Development Mode
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    // Production Mode
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`OncoVista AI Full-Stack Server active on: http://0.0.0.0:${PORT}`);
  });
}

runApplication();
