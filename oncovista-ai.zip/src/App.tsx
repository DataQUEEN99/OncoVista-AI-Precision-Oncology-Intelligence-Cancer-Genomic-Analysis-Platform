import React from "react";
import { 
  ViewState, 
  Patient, 
  Mutation, 
  UserSession 
} from "./types";
import { 
  Users, 
  Dna, 
  Upload, 
  BrainCircuit, 
  Activity, 
  BarChart, 
  Compass, 
  FileText, 
  Cpu, 
  Lock, 
  LogOut, 
  Menu, 
  X, 
  Award, 
  Pill, 
  TrendingUp, 
  Layers,
  Settings,
  HelpCircle,
  Database
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

import LandingFeatures from "./components/LandingFeatures";
import DashboardOverview from "./components/DashboardOverview";
import MutationUpload from "./components/MutationUpload";
import VariantAnnotation from "./components/VariantAnnotation";
import BiomarkerIntelligence from "./components/BiomarkerIntelligence";
import TherapyRecommendation from "./components/TherapyRecommendation";
import SurvivalAnalysis from "./components/SurvivalAnalysis";
import TCGAAnalytics from "./components/TCGAAnalytics";
import TumorEvolution from "./components/TumorEvolution";
import AIReportGenerator from "./components/AIReportGenerator";

export default function App() {
  const [view, setView] = React.useState<ViewState>("landing");
  const [session, setSession] = React.useState<UserSession | null>(null);
  
  const [patients, setPatients] = React.useState<Patient[]>([]);
  const [activePatient, setActivePatient] = React.useState<Patient | null>(null);
  const [transientMutations, setTransientMutations] = React.useState<Mutation[]>([]);
  const [loadingPatients, setLoadingPatients] = React.useState(false);
  
  // Sidebar state
  const [sidebarExpanded, setSidebarExpanded] = React.useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  // Fetch initial patient profiles from Express backend
  const loadCohortPatients = async () => {
    setLoadingPatients(true);
    try {
      const res = await fetch("/api/patients");
      const data = await res.json();
      if (res.ok) {
        setPatients(data);
        if (data.length > 0 && !activePatient) {
          // Default selection fallback
          setActivePatient(data[0]);
        }
      }
    } catch (err) {
      console.error("Clinical sequence database offline:", err);
    } finally {
      setLoadingPatients(false);
    }
  };

  React.useEffect(() => {
    loadCohortPatients();
  }, []);

  // When active patient changes on server side, reflect it here
  const syncAndSelectPatient = (p: Patient) => {
    setActivePatient(p);
    // Overwrite in lists
    setPatients(prev => prev.map(item => item.id === p.id ? p : item));
  };

  const handleTransientParsed = (muts: Mutation[]) => {
    setTransientMutations(muts);
    // Shift focus over Variant Annotation Bench
    setView("variant-analysis");
  };

  const handleLogout = () => {
    setSession(null);
    setView("landing");
  };

  // Safe sidebar navigation options mapping
  const navItems = [
    { id: "dashboard", label: "Cohort Dashboard", icon: BarChart },
    { id: "upload", label: "Plate Aligner (Upload)", icon: Upload },
    { id: "variant-analysis", label: "Somatic Annotator", icon: Dna },
    { id: "biomarkers", label: "Biomarker Hub", icon: Award },
    { id: "therapies", label: "Therapeutic Matches", icon: Pill },
    { id: "survival", label: "Cox Survival Analytics", icon: TrendingUp },
    { id: "tcga", label: "TCGA Multi-Omics", icon: Layers },
    { id: "evolution", label: "Clonal drift Sandbox", icon: Compass },
    { id: "reports", label: "Advisory Reports", icon: FileText }
  ];

  return (
    <div className="min-h-screen text-zinc-100 flex flex-col font-sans selection:bg-purple-600 selection:text-white">
      
      {/* Top Professional Header Bar */}
      <header className="sticky top-0 z-50 bg-[#05020d]/80 backdrop-blur-xl border-b border-[#22143a]/60 h-16 w-full px-4 md:px-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {session && (
            <button 
              onClick={() => {
                setSidebarExpanded(!sidebarExpanded);
                // Also toggle mobile menu
                setMobileMenuOpen(!mobileMenuOpen);
              }}
              className="lg:hidden p-2 rounded-xl text-zinc-400 hover:text-white bg-zinc-950/40 border border-zinc-900 transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}

          <div 
            onClick={() => setView(session ? "dashboard" : "landing")}
            className="flex items-center gap-2 cursor-pointer select-none group"
          >
            <div className="p-1.5 rounded-lg bg-gradient-to-tr from-neon-purple to-neon-pink text-white shadow-md shadow-purple-500/20">
              <BrainCircuit className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <span className="font-display font-medium text-sm md:text-base tracking-tight text-white uppercase group-hover:text-purple-400 transition-colors">OncoVista AI</span>
              <span className="text-[9px] font-mono block text-zinc-500 leading-none">Genomic Diagnostics Core</span>
            </div>
          </div>
        </div>

        {/* Global Patient selector state indicators */}
        {session && activePatient && (
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-purple-950/25 border border-purple-900/40 text-xs">
            <span className="w-2 h-2 rounded-full bg-purple-500 animate-pulse" />
            <span className="font-mono text-zinc-500">ACTIVE GENOMICS TARGET:</span>
            <strong className="text-zinc-250 text-white font-bold">{activePatient.id} - {activePatient.name}</strong>
          </div>
        )}

        {/* Right Session credentials & state */}
        <div className="flex items-center gap-3">
          {session ? (
            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-xs font-semibold block text-zinc-200">{session.name}</span>
                <span className="text-[9px] font-mono text-pink-400 uppercase tracking-widest">{session.role} LEVEL ACCESS</span>
              </div>
              
              <button 
                onClick={handleLogout}
                className="p-2 bg-zinc-950/60 border border-zinc-904 hover:border-rose-500/30 hover:bg-rose-550 hover:text-rose-450 transition-all rounded-xl text-zinc-400 cursor-pointer"
                title="Disconnect Medical Session"
              >
                <LogOut className="w-4 h-4 hover:text-rose-400" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-xs font-mono text-zinc-500">
              <Lock className="w-3.5 h-3.5 text-purple-400" />
              <span>SECURED PROTOCOL SSL</span>
            </div>
          )}
        </div>
      </header>

      {/* Main Core Body Container */}
      <div className="flex-1 flex w-full relative">
        
        {/* Dynamic Navigation Sidebar */}
        {session && (
          <aside 
            className={`hidden lg:flex flex-col border-r border-[#22143a]/60 bg-[#070311]/90 backdrop-blur-md transition-all duration-300 relative ${
              sidebarExpanded ? "w-64" : "w-16"
            } self-stretch select-none`}
          >
            {/* Nav Items Scroll List */}
            <div className="flex-1 py-6 px-3 space-y-1.5 overflow-y-auto">
              {navItems.map((item) => {
                const isActive = view === item.id;
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => setView(item.id as ViewState)}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all cursor-pointer border ${
                      isActive 
                        ? "bg-purple-950/20 border-purple-500/50 text-white font-bold shadow-md shadow-purple-500/5 text-bold" 
                        : "text-zinc-400 border-transparent hover:text-white hover:bg-zinc-950/40"
                    }`}
                  >
                    <Icon className={`w-5 h-5 shrink-0 ${isActive ? "text-purple-400" : "text-zinc-500"}`} />
                    
                    {sidebarExpanded && (
                      <span className="text-xs text-left truncate">{item.label}</span>
                    )}

                    {isActive && sidebarExpanded && (
                      <span className="ml-auto w-1.5 h-1.5 rounded-full bg-purple-400 animate-ping" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Sidebar Collapse Toggle button bottom */}
            <div className="p-4 border-t border-[#22143a]/40 text-center">
              <button 
                onClick={() => setSidebarExpanded(!sidebarExpanded)}
                className="text-xs text-zinc-500 hover:text-zinc-350 font-mono transition-colors"
              >
                {sidebarExpanded ? "Collapse Navigation" : "»"}
              </button>
            </div>
          </aside>
        )}

        {/* Mobile menu panel overlay drawer */}
        {session && mobileMenuOpen && (
          <div className="absolute inset-0 z-40 bg-[#05020d]/95 lg:hidden flex flex-col p-6 space-y-6">
            <div className="flex items-center justify-between border-b border-zinc-900 pb-4">
              <h3 className="text-sm font-display font-medium text-white flex items-center gap-1.5">
                <BrainCircuit className="w-5 h-5 text-purple-400" />
                Workspace Menu
              </h3>
              <button 
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 rounded-xl bg-zinc-900 text-zinc-400"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 flex-1 overflow-y-auto">
              {navItems.map((item) => {
                const isActive = view === item.id;
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setView(item.id as ViewState);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 p-3.5 rounded-xl border ${
                      isActive 
                        ? "bg-purple-950/30 border-purple-500/55 text-white" 
                        : "text-zinc-400 border-zinc-900 hover:text-white"
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="text-xs">{item.label}</span>
                  </button>
                );
              })}
            </div>

            <div className="pt-4 border-t border-zinc-900 text-center">
              <button 
                onClick={handleLogout}
                className="w-full py-3 bg-rose-500/10 text-rose-450 border border-rose-500/20 rounded-xl text-xs font-semibold"
              >
                Disconnect Medical Session
              </button>
            </div>
          </div>
        )}

        {/* Core Screen Frame */}
        <main className="flex-1 p-4 md:p-6 lg:p-8 overflow-y-auto max-w-[1720px] mx-auto w-full z-10">
          <AnimatePresence mode="wait">
            <motion.div
              key={view}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.18 }}
              className="w-full"
            >
              {view === "landing" && (
                <LandingFeatures 
                  setView={setView} 
                  onLoginSuccess={(usr) => setSession(usr)} 
                />
              )}

              {view === "dashboard" && (
                <DashboardOverview 
                  patients={patients}
                  activePatient={activePatient}
                  setActivePatient={syncAndSelectPatient}
                  setView={setView}
                />
              )}

              {view === "upload" && (
                <MutationUpload 
                  patients={patients}
                  activePatient={activePatient}
                  setActivePatient={syncAndSelectPatient}
                  onMutationParsed={handleTransientParsed}
                  setView={setView}
                />
              )}

              {view === "variant-analysis" && (
                <VariantAnnotation 
                  patients={patients}
                  activePatient={activePatient}
                  transientMutations={transientMutations}
                  setView={setView}
                />
              )}

              {view === "biomarkers" && (
                <BiomarkerIntelligence 
                  setView={setView} 
                />
              )}

              {view === "therapies" && (
                <TherapyRecommendation 
                  patients={patients}
                  activePatient={activePatient}
                  setView={setView}
                />
              )}

              {view === "survival" && (
                <SurvivalAnalysis 
                  setView={setView} 
                />
              )}

              {view === "tcga" && (
                <TCGAAnalytics 
                  setView={setView} 
                />
              )}

              {view === "evolution" && (
                <TumorEvolution 
                  activePatient={activePatient}
                  setView={setView} 
                />
              )}

              {view === "reports" && (
                <AIReportGenerator 
                  activePatient={activePatient}
                  setView={setView} 
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>

      </div>

      {/* Futuristic Clinical Footer */}
      <footer className="py-4 border-t border-[#22143a]/40 bg-[#05020d] text-center text-[10px] font-mono text-zinc-500 flex flex-col md:flex-row items-center justify-between px-6 z-10 gap-2 select-none">
        <div>
          OncoVista AI System core initialized index :: <span className="text-emerald-400">ACTIVE CONNECTED</span>
        </div>
        <div className="flex items-center gap-4">
          <span>COHORT ALIGNER: GRCh38.p14</span>
          <span>SSL CODES SHIELDED</span>
          <span>© 2026 ONCOVISTA PRECISION THERAPEUTICS</span>
        </div>
      </footer>

    </div>
  );
}
