import React from "react";
import { Patient, Mutation, AIInterpretation, ViewState } from "../types";
import { Sparkles, BrainCircuit, Activity, ShieldAlert, Cpu, Layers, HelpCircle } from "lucide-react";
import { motion } from "motion/react";

interface VariantProps {
  patients: Patient[];
  activePatient: Patient | null;
  transientMutations: Mutation[]; // Mutations loaded via temporary file
  setView: (v: ViewState) => void;
}

export default function VariantAnnotation({ patients, activePatient, transientMutations, setView }: VariantProps) {
  const [selectedMutation, setSelectedMutation] = React.useState<Mutation | null>(null);
  const [aiAnalysis, setAiAnalysis] = React.useState<AIInterpretation | null>(null);
  const [loadingAI, setLoadingAI] = React.useState(false);
  const [networkError, setNetworkError] = React.useState("");

  // Amalgamate patient's active mutations and any temporary uploaded mutations
  const mutationsList = React.useMemo(() => {
    const list: Mutation[] = [];
    if (activePatient) {
      list.push(...activePatient.mutations);
    }
    // If no active patient, render transiently loaded mutations
    if (list.length === 0 && transientMutations.length > 0) {
      list.push(...transientMutations);
    }
    return list;
  }, [activePatient, transientMutations]);

  // Set default selection when component mounts or mutation list alters
  React.useEffect(() => {
    if (mutationsList.length > 0 && !selectedMutation) {
      setSelectedMutation(mutationsList[0]);
    }
  }, [mutationsList]);

  // Clear AI analysis when mutation alters
  React.useEffect(() => {
    setAiAnalysis(null);
    setNetworkError("");
  }, [selectedMutation]);

  // Trigger server-side OncoVista Gemini oncology interpretation
  const handleAIInterpret = async () => {
    if (!selectedMutation) return;
    setLoadingAI(true);
    setAiAnalysis(null);
    setNetworkError("");

    try {
      const patientContext = activePatient 
        ? `Case Study for ${activePatient.name}, ${activePatient.age}yo ${activePatient.gender}, diagnosed with ${activePatient.diagnosis} (${activePatient.stage}).`
        : "Transient DNA Sequencing annotation.";

      const res = await fetch("/api/gemini/interpret", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          gene: selectedMutation.gene,
          variant: selectedMutation.variant,
          patientContext
        })
      });

      const data = await res.json();
      if (res.ok) {
        setAiAnalysis(data.analysis);
      } else {
        setNetworkError(data.error || "Interpretation model fell offline.");
      }
    } catch (err: any) {
      setNetworkError(`Communication error with OncoVista AI services: ${err.message}`);
    } finally {
      setLoadingAI(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-purple-400 uppercase tracking-widest flex items-center gap-2">
            <Cpu className="w-3.5 h-3.5" />
            Genomic Variant Annotation Bench
          </div>
          <h1 className="text-2xl font-display font-medium text-white tracking-tight mt-1">
            Precision Variant Interpreter
          </h1>
          <p className="text-zinc-400 text-xs md:text-sm mt-1 max-w-2xl">
            Analyze Somatic Pathogenicity indexes, Variant Allele Frequencies (VAF), and trigger generative AI molecular board summaries for targeted drug matches.
          </p>
        </div>

        {activePatient && (
          <div className="bg-purple-950/20 border border-purple-900/40 px-4 py-2.5 rounded-xl text-xs flex items-center gap-2">
            <Activity className="w-4 h-4 text-purple-400" />
            <div>
              <span className="text-zinc-500 font-mono text-[9px] uppercase block">Selected Case Profile</span>
              <strong className="text-white">{activePatient.name} ({activePatient.id})</strong>
            </div>
          </div>
        )}
      </div>

      {mutationsList.length === 0 ? (
        <div className="text-center py-16 glass-panel rounded-2xl space-y-4 max-w-lg mx-auto">
          <HelpCircle className="w-12 h-12 text-zinc-600 mx-auto" />
          <div>
            <h3 className="text-base font-display font-medium text-white">No active mutations sequenced</h3>
            <p className="text-xs text-zinc-500 mt-1 max-w-sm mx-auto">
              Please choose a patient with mutations from the dashboard roster, or upload a somatic target sequencing log to start annotating variants.
            </p>
          </div>
          <button 
            onClick={() => setView("upload")}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-purple-600 hover:bg-purple-750 text-white cursor-pointer"
          >
            Go to Mutation Upload
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Left Column: List of Mutations */}
          <div className="space-y-4">
            <div className="glass-panel rounded-2xl p-4 space-y-3">
              <h3 className="text-xs font-mono text-zinc-400 uppercase tracking-widest">Sequenced Mutations ({mutationsList.length})</h3>
              
              <div className="space-y-2 max-h-[480px] overflow-y-auto pr-1">
                {mutationsList.map((m, idx) => {
                  const isSelected = selectedMutation?.gene === m.gene && selectedMutation?.variant === m.variant;
                  return (
                    <div 
                      key={idx}
                      onClick={() => setSelectedMutation(m)}
                      className={`p-3.5 rounded-xl cursor-pointer transition-all border text-left ${
                        isSelected 
                          ? "bg-purple-950/25 border-purple-500/50 shadow-md shadow-gradient" 
                          : "bg-zinc-950/25 border-zinc-900 hover:border-purple-900/30"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-display font-semibold text-white">{m.gene}</span>
                        <span className={`px-2 py-0.5 rounded text-[9px] font-mono uppercase ${
                          m.pathogenicity === "Pathogenic" 
                            ? "bg-rose-500/15 text-rose-400 border border-rose-500/20" 
                            : "bg-amber-500/15 text-amber-400 border border-amber-500/20"
                        }`}>
                          {m.pathogenicity}
                        </span>
                      </div>
                      
                      <div className="text-xs text-zinc-400 font-mono mt-1.5">{m.variant}</div>
                      
                      <div className="grid grid-cols-2 gap-2 mt-3 pt-2.5 border-t border-zinc-900 font-mono text-[10px] text-zinc-500">
                        <div>
                          VAF Ratio: <strong className="text-zinc-300 font-bold">{(m.vaf * 100).toFixed(1)}%</strong>
                        </div>
                        <div>
                          Read Depth: <strong className="text-zinc-300 font-bold">{m.depth}x</strong>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="p-4 bg-zinc-950/80 border border-zinc-900 rounded-2xl text-[11px] text-zinc-400 space-y-2">
              <div className="font-semibold text-zinc-300 flex items-center gap-1">
                <Layers className="w-3.5 h-3.5 text-purple-400" />
                Variant Allele Frequency Note
              </div>
              <p className="leading-relaxed text-zinc-500 font-sans">
                A VAF ratio of &gt;40% usually indicates dominant clonal drivers or germline inheritance, whereas a VAF of &lt;15% suggests subclonal therapeutic drift or somatic branch metastasis.
              </p>
            </div>
          </div>

          {/* Right 2 Columns: Detailed Annotation display */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Somatic Selection overview card */}
            {selectedMutation && (
              <div className="glass-panel rounded-2xl p-6 space-y-6 relative overflow-hidden">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-zinc-900">
                  <div>
                    <span className="text-xs font-mono text-purple-400 block uppercase">Selected Target Alteration</span>
                    <h2 className="text-2xl font-display font-medium text-white flex items-center gap-2.5 mt-0.5">
                      {selectedMutation.gene}
                      <span className="text-sm font-sans font-normal text-zinc-500 font-mono">[{selectedMutation.variant}]</span>
                    </h2>
                    <span className="text-xs text-zinc-400 mt-1 block font-mono">{selectedMutation.consequence} Mutation</span>
                  </div>

                  <button 
                    onClick={handleAIInterpret}
                    disabled={loadingAI}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-neon-purple to-neon-pink text-xs font-semibold text-white shadow-lg shadow-purple-500/20 hover:opacity-95 active:scale-95 disabled:opacity-50 checked:opacity-100 cursor-pointer flex items-center gap-1.5 transition-all self-start md:self-center"
                  >
                    <Sparkles className="w-4 h-4 text-white animate-pulse" />
                    {loadingAI ? "Conducting AI Evaluation..." : "AI Interpret with Gemini"}
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-zinc-900/30 border border-zinc-800">
                    <span className="text-[10px] font-mono text-zinc-500 uppercase">Clonality Metric (VAF Intensity)</span>
                    <div className="flex items-center gap-3 mt-2">
                      <div className="text-2xl font-display font-bold text-white">{(selectedMutation.vaf * 100).toFixed(1)}%</div>
                      <div className="w-full bg-zinc-800 rounded-full h-2 overflow-hidden">
                        <div className="bg-purple-500 h-full" style={{ width: `${selectedMutation.vaf * 100}%` }} />
                      </div>
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-zinc-900/30 border border-zinc-800">
                    <span className="text-[10px] font-mono text-zinc-500 uppercase">Pathogenic Classification</span>
                    <div className="text-base font-bold text-rose-400 flex items-center gap-1.5 mt-2">
                      <ShieldAlert className="w-4 h-4" />
                      {selectedMutation.pathogenicity} Diagnostic Marker
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="text-[10px] font-mono text-zinc-500 uppercase">Local Database Significance Synopsis</span>
                  <p className="text-xs leading-relaxed text-zinc-300 bg-zinc-950/40 p-4 rounded-xl border border-zinc-900">
                    {selectedMutation.clinicalSignificance}
                  </p>
                </div>
              </div>
            )}

            {/* AI Results Output Container */}
            {loadingAI && (
              <div className="p-12 text-center glass-panel rounded-2xl space-y-4">
                <BrainCircuit className="w-12 h-12 text-purple-400 animate-spin mx-auto" />
                <div className="space-y-1">
                  <h3 className="text-base font-display font-medium text-white">Consulting OncoVista Biotech-AI models...</h3>
                  <p className="text-xs text-zinc-500 max-w-sm mx-auto">
                    Parsing gene sequencing metrics, double strands, ATP binding clefts, and reviewing FDA precision oncology databases.
                  </p>
                </div>
              </div>
            )}

            {networkError && (
              <div className="p-4 border border-rose-500/20 bg-rose-500/5 rounded-xl text-xs text-rose-400 text-center">
                {networkError}
              </div>
            )}

            {aiAnalysis && (
              <motion.div 
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-4"
              >
                <div className="p-4 bg-purple-950/20 border border-purple-500/30 rounded-2xl flex items-center gap-3">
                  <Sparkles className="w-5 h-5 text-purple-400 flex-shrink-0" />
                  <div>
                    <h4 className="text-xs font-mono font-bold text-purple-400">OncoVista Clinical AI Annotation</h4>
                    <p className="text-[11px] text-zinc-400 mt-0.5">Biotech-grade genomic interpretation generated in real time with server-side AI.</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[
                    { title: "Oncogenic Pathological Mechanism", text: aiAnalysis.mechanism, highlight: "border-l-2 border-purple-500" },
                    { title: "Matched Targeted Therapies (FDA)", text: aiAnalysis.targetedTherapies, highlight: "border-l-2 border-blue-500" },
                    { title: "Somatic Resistance and Bypass Warnings", text: aiAnalysis.resistanceMarkers, highlight: "border-l-2 border-pink-500" },
                    { title: "Cohort Survival & Prognostic Evaluation", text: aiAnalysis.prognosticImpact, highlight: "border-l-2 border-amber-500" },
                    { title: "Onco-Basket active Clinical Trials", text: aiAnalysis.clinicalTrialSuggestion, highlight: "border-l-2 border-emerald-500" }
                  ].map((card, idx) => (
                    <div key={idx} className={`p-4 bg-zinc-900/30 border border-zinc-800 rounded-xl space-y-1.5 ${card.highlight}`}>
                      <h4 className="text-[10px] font-mono text-zinc-400 uppercase tracking-wider">{card.title}</h4>
                      <p className="text-xs leading-relaxed text-zinc-300">{card.text}</p>
                    </div>
                  ))}
                </div>

                {/* Tumor board step by step recomendation card */}
                {aiAnalysis.tumorBoardRecommendation && (
                  <div className="p-5 bg-gradient-to-br from-purple-950/20 to-pink-950/10 border border-purple-900/30 rounded-2xl space-y-2">
                    <h4 className="text-xs font-mono text-purple-300 uppercase tracking-widest flex items-center gap-1.5 font-bold">
                      <Sparkles className="w-4 h-4 text-purple-400" />
                      Suggested Step-by-Step Tumor Board Guidelines
                    </h4>
                    <p className="text-xs leading-relaxed text-zinc-300 whitespace-pre-line bg-zinc-950/40 p-3.5 rounded-xl border border-zinc-900">
                      {aiAnalysis.tumorBoardRecommendation}
                    </p>
                  </div>
                )}
              </motion.div>
            )}

          </div>

        </div>
      )}
    </div>
  );
}
