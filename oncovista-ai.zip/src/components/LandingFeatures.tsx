import React from "react";
import { ViewState, UserSession } from "../types";
import { motion } from "motion/react";
import BiotechHelix from "./BiotechHelix";
import { 
  Lock, 
  GitBranch, 
  Eye, 
  Sparkles, 
  Settings, 
  UserPlus, 
  ShieldCheck, 
  Database,
  ArrowRight,
  TrendingUp,
  Cpu,
  Bookmark
} from "lucide-react";

interface LandingProps {
  onLoginSuccess: (session: UserSession) => void;
  setView: (v: ViewState) => void;
}

export default function LandingFeatures({ onLoginSuccess, setView }: LandingProps) {
  const [email, setEmail] = React.useState("onco.specialist@hospital.org");
  const [password, setPassword] = React.useState("oncocore2026");
  const [name, setName] = React.useState("Dr. Sarah Lin");
  const [role, setRole] = React.useState<"Clinician" | "Researcher" | "Admin">("Clinician");
  
  const [isRegistering, setIsRegistering] = React.useState(false);
  const [authError, setAuthError] = React.useState("");
  const [isWorking, setIsWorking] = React.useState(false);

  // Authenticate clinical specialist session
  const handleSubmitAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setIsWorking(true);

    const apiEndpoint = isRegistering ? "/api/auth/register" : "/api/auth/login";
    
    try {
      const response = await fetch(apiEndpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, name, role })
      });

      const data = await response.json();
      if (response.ok) {
        onLoginSuccess({
          email: data.user.email,
          name: data.user.name,
          role: data.user.role,
          token: data.token
        });
        setView("dashboard");
      } else {
        setAuthError(data.error || "Authentication failed. Validate your credentials.");
      }
    } catch (err: any) {
      setAuthError(`Connection timed out: ${err.message}`);
    } finally {
      setIsWorking(false);
    }
  };

  return (
    <div className="relative min-h-[90vh] py-12 flex flex-col items-center justify-center">
      {/* Absolute Biotech grid backdrops */}
      <div className="biotech-bg-grid" />

      {/* Hero Header Area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center w-full max-w-7xl relative z-10">
        
        {/* Left Side: DNA Helix & Cinematic Pitch */}
        <div className="lg:col-span-7 space-y-8 text-left">
          
          <div className="space-y-4">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-purple-950/40 border border-purple-500/20 text-xs font-mono text-purple-350 tracking-wider"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-purple-500 animate-ping" />
              Somatic Variant Intelligence Platform v3.5
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-4xl md:text-5xl font-display font-bold text-white tracking-tight leading-tight uppercase"
            >
              AI-Powered Precision <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 neon-text-glow">
                Oncology Intelligence
              </span>
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-zinc-400 text-sm md:text-base leading-relaxed max-w-xl font-sans"
            >
              Transform raw DNA tumor sequencing files into validated clinical interpretations, Cox-hazard ratios, and adaptive FDA therapeutic matched trials using advanced cloud AI and bioinformatics.
            </motion.p>
          </div>

          {/* DNA Helix */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="w-full relative"
          >
            <BiotechHelix />
          </motion.div>

          {/* Key capability bullet points (glassy tags) */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { icon: Database, label: "Variant Annotator", text: "Pathogenicity mapping" },
              { icon: TrendingUp, label: "Cox Survival curves", text: "Kaplan-Meier projections" },
              { icon: GitBranch, label: "Clonal Drift Sandbox", text: "Selective pressure trees" },
              { icon: Cpu, label: "LLM Tumor Boards", text: "Advisory report builders" }
            ].map((cap, idx) => (
              <div 
                key={idx}
                className="p-3 bg-zinc-950/40 border border-zinc-900 rounded-xl space-y-1"
              >
                <cap.icon className="w-4 h-4 text-purple-400" />
                <div className="text-[11px] font-display font-medium text-white">{cap.label}</div>
                <div className="text-[9px] text-zinc-500 font-mono">{cap.text}</div>
              </div>
            ))}
          </div>

        </div>

        {/* Right Side: Glassmorphism login & Register panel */}
        <div className="lg:col-span-5 w-full max-w-md mx-auto">
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.98, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="p-6 glass-panel rounded-3xl space-y-6 relative overflow-hidden"
          >
            {/* Soft decorative glow */}
            <div className="absolute top-0 right-0 w-24 h-24 bg-pink-500/5 rounded-full blur-[40px]" />
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-purple-500/5 rounded-full blur-[40px]" />

            <div className="text-center space-y-1">
              <h2 className="text-xl font-display font-semibold text-white tracking-tight">
                {isRegistering ? "Register New Account" : "Clinician Specialist Portal"}
              </h2>
              <p className="text-zinc-500 text-xs">
                {isRegistering 
                  ? "Initialize clinical workspace authentication files." 
                  : "Connect to the precision oncology diagnostic server."}
              </p>
            </div>

            <form onSubmit={handleSubmitAuth} className="space-y-4 text-xs">
              
              {isRegistering && (
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono uppercase text-zinc-500 block">Full Name & Degree</label>
                  <input 
                    type="text" 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    placeholder="e.g. Dr. Sarah Lin PhD"
                    className="w-full bg-zinc-950/80 border border-zinc-805 rounded-xl p-3 text-white focus:outline-none focus:border-purple-500 text-xs"
                  />
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono uppercase text-zinc-500 block">Workplace Email Address</label>
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="e.g. sarah.lin@academicmedicine.org"
                  className="w-full bg-zinc-950/80 border border-zinc-805 rounded-xl p-3 text-white focus:outline-none focus:border-purple-500 text-xs"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] font-mono uppercase text-zinc-500 block font-normal">Security Password</label>
                  {!isRegistering && (
                    <span className="text-[9px] font-mono text-zinc-600 hover:text-purple-400 cursor-pointer">
                      Forgot Credentials?
                    </span>
                  )}
                </div>
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  placeholder="Password value"
                  className="w-full bg-zinc-950/80 border border-zinc-805 rounded-xl p-3 text-white focus:outline-none focus:border-purple-500 text-xs"
                />
              </div>

              {/* Specialist Role Selector */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono uppercase text-zinc-500 block font-normal">Assigned Medical Role</label>
                <div className="grid grid-cols-3 gap-2 p-1 bg-zinc-950 border border-zinc-900 rounded-xl">
                  {["Clinician", "Researcher", "Admin"].map((r) => (
                    <button 
                      key={r}
                      type="button"
                      onClick={() => setRole(r as any)}
                      className={`py-2 rounded-lg text-[10px] font-mono tracking-wider font-semibold transition-colors cursor-pointer ${
                        role === r 
                          ? "bg-purple-900/40 text-purple-300 border border-purple-800/60" 
                          : "text-zinc-500 hover:text-zinc-350"
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>

              {/* Developer credentials warning bypass */}
              <div className="p-3 bg-purple-950/20 border border-purple-900/30 text-[9px] font-mono text-purple-300 leading-relaxed rounded-xl flex items-start gap-1.5">
                <ShieldCheck className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
                <p>
                  Sandbox Mode active. Standard credentials can bypass safety checks: email: <strong className="text-white">onco.specialist@hospital.org</strong> with password <strong className="text-white">oncocore2026</strong>.
                </p>
              </div>

              {authError && (
                <div className="p-3 border border-rose-500/20 bg-rose-500/5 text-rose-400 rounded-xl text-[10px] font-mono text-center">
                  {authError}
                </div>
              )}

              {/* Action trigger button */}
              <button 
                type="submit"
                disabled={isWorking}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-neon-purple via-pink-500 to-neon-pink text-xs font-semibold text-white cursor-pointer shadow-lg shadow-purple-500/25 hover:opacity-95 flex items-center justify-center gap-1.5 transition-all text-center uppercase tracking-wider"
              >
                <span>{isWorking ? "Authenticating session..." : isRegistering ? "Generate active clinician profile" : "Establish secure workspace"}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

            </form>

            {/* Selector to shift */}
            <div className="text-center pt-2">
              <span className="text-[10px] text-zinc-500">
                {isRegistering ? "Already have clinical workspace credentials? " : "New to the OncoVista AI oncology workspace? "}
                <strong 
                  onClick={() => setIsRegistering(!isRegistering)}
                  className="text-purple-400 hover:text-white underline font-semibold font-mono cursor-pointer ml-1"
                >
                  {isRegistering ? "Establish Workspace Portal" : "Join Platform Core"}
                </strong>
              </span>
            </div>

          </motion.div>

        </div>

      </div>
    </div>
  );
}
