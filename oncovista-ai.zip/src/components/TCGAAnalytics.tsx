import React from "react";
import { ViewState, TCGACohort } from "../types";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, ScatterChart, Scatter, ZAxis, Cell, ReferenceLine } from "recharts";
import { Info, HelpCircle, Activity, Globe, Flame, Layers } from "lucide-react";
import { motion } from "motion/react";

interface TCGAProps {
  setView: (v: ViewState) => void;
}

export default function TCGAAnalytics({ setView }: TCGAProps) {
  const [selectedCohort, setSelectedCohort] = React.useState<"LUAD" | "COAD" | "BRCA" | "SKCM">("LUAD");
  const [cohorts, setCohorts] = React.useState<Record<string, TCGACohort>>({});
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    fetch("/api/cohorts")
      .then((res) => res.json())
      .then((data) => {
        setCohorts(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Cohort fetch failed:", err);
        setLoading(false);
      });
  }, []);

  const activeCohortData = cohorts[selectedCohort];

  // Custom volcano plot dataset represent fold change and p-value for somatic markers
  const volcanoData = [
    { name: "TP53", log2FC: -2.4, negLogP: 6.8, size: 100, significance: "Significantly Downregulated" },
    { name: "EGFR", log2FC: 3.5, negLogP: 8.2, size: 120, significance: "Significantly Overexpressed" },
    { name: "KRAS", log2FC: 2.8, negLogP: 7.4, size: 110, significance: "Significantly Overexpressed" },
    { name: "BRCA1", log2FC: -1.8, negLogP: 4.1, size: 80, significance: "Moderately Downregulated" },
    { name: "MET", log2FC: 4.1, negLogP: 5.5, size: 90, significance: "Significantly Overexpressed" },
    { name: "PTEN", log2FC: -3.1, negLogP: 5.9, size: 95, significance: "Significantly Deleted" },
    { name: "APC", log2FC: -4.5, negLogP: 9.1, size: 130, significance: "Severely Downregulated" },
    { name: "ALCK", log2FC: 1.2, negLogP: 2.1, size: 60, significance: "Insignificant Variant" },
    { name: "BRAF", log2FC: 1.9, negLogP: 3.8, size: 70, significance: "Moderately Elevated" },
    { name: "MYC", log2FC: 3.2, negLogP: 7.8, size: 115, significance: "Significantly Overexpressed" },
  ];

  // Custom visual pathways
  const enrichedPathways = [
    { name: "PI3K-Akt-mTOR Cascades", status: "Hyperactive", percentage: 84, color: "bg-rose-500", evidence: "PTEN loss & PIK3CA activation feedback" },
    { name: "MAPK Mitogenic Transduction", status: "Hyperactive", percentage: 76, color: "bg-rose-500", evidence: "EGFR / KRAS point-mutations over-stim" },
    { name: "DNA Double Strand Repair (HRD)", status: "Deficient", percentage: 41, color: "bg-amber-500", evidence: "Germline BRCA1/2 and ATM deletions" },
    { name: "Wnt-BetaCatenin Proliferation", status: "Hyperactive", percentage: 92, color: "bg-rose-500", evidence: "APC frame-shifts and Axin truncations" },
    { name: "G1/S Cell Cycle Transition Checkpoint", status: "Deficient", percentage: 38, color: "bg-emerald-500", evidence: "TP53 mutations blocking p21 activation" },
  ];

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-purple-400 uppercase tracking-widest flex items-center gap-2">
            <Globe className="w-3.5 h-3.5" />
            TCGA Global Genomics Repositories
          </div>
          <h1 className="text-2xl font-display font-medium text-white tracking-tight mt-1">
            TCGA Multi-Omic Analytics
          </h1>
          <p className="text-zinc-400 text-xs md:text-sm mt-1 max-w-2xl">
            Sift through Cancer Genome Atlas cohorts to locate driver mutation frequencies, map overactivated target expression pathways and plot genomic volcano maps.
          </p>
        </div>

        {/* Selector */}
        <div className="flex bg-zinc-950 border border-zinc-900 rounded-xl p-1 text-xs font-mono self-start md:self-center">
          {["LUAD", "COAD", "BRCA", "SKCM"].map((cohort) => (
            <button 
              key={cohort}
              onClick={() => setSelectedCohort(cohort as any)}
              className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                selectedCohort === cohort 
                  ? "bg-purple-600 text-white font-bold" 
                  : "text-zinc-400 hover:text-white"
              }`}
            >
              {cohort}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Volcano Plot and driver frequencies */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Scatter Volcano Plot */}
          <div className="glass-panel rounded-2xl p-5 space-y-4">
            <div>
              <h3 className="text-xs font-mono text-pink-400 uppercase tracking-widest">Somatic Expression Mapping</h3>
              <h2 className="text-sm font-display font-medium text-white">Genomic Volcano Plot (Fold-Change vs Significance)</h2>
            </div>

            <div className="h-64 w-full text-xs font-mono mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 10, right: 10, bottom: 0, left: -25 }}>
                  <XAxis 
                    type="number" 
                    dataKey="log2FC" 
                    name="log2 Fold-Change" 
                    stroke="#52525b" 
                    domain={[-6, 6]}
                    label={{ value: "log2 Fold-Change (Normal vs Tumor)", position: "insideBottom", offset: -5, fill: "#71717a" }}
                  />
                  <YAxis 
                    type="number" 
                    dataKey="negLogP" 
                    name="-log10 p-Value" 
                    stroke="#52525b" 
                    domain={[0, 11]}
                    label={{ value: "-log10 p-Value (Significance)", angle: -90, position: "insideLeft", offset: 15, fill: "#71717a" }}
                  />
                  <ZAxis type="number" dataKey="size" range={[60, 250]} />
                  <Tooltip 
                    cursor={{ strokeDasharray: "3 3" }} 
                    contentStyle={{ backgroundColor: "#0e071c", borderColor: "#a855f7" }}
                    formatter={(value, name, props) => {
                      if (name === "log2 Fold-Change") return [`${value} (Fold-Change)`];
                      if (name === "-log10 p-Value") return [`${value} (Sig)`];
                      return [value];
                    }}
                  />
                  
                  {/* Vertical & Horizontal Center lines */}
                  <ReferenceLine x={0} stroke="#3f3f46" strokeDasharray="3 3" />
                  <ReferenceLine y={4} stroke="#3f3f46" strokeDasharray="3 3" />

                  <Scatter name="Genomics Elements" data={volcanoData} fill="#8884d8">
                    {volcanoData.map((entry, index) => {
                      const isSignificantUp = entry.log2FC > 1.5 && entry.negLogP > 4;
                      const isSignificantDown = entry.log2FC < -1.5 && entry.negLogP > 4;
                      const nodeColor = isSignificantUp ? "#f43f5e" : isSignificantDown ? "#3b82f6" : "#71717a";
                      return (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={nodeColor} 
                          filter="drop-shadow(0 0 6px rgba(168, 85, 247, 0.15))"
                        />
                      );
                    })}
                  </Scatter>
                </ScatterChart>
              </ResponsiveContainer>
            </div>

            <div className="flex justify-around text-[10px] font-mono text-zinc-500 pt-2 border-t border-zinc-900">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-500" />
                Oncogenic Drivers (Overexpressed)
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-blue-500" />
                Tumor Suppressors (Deleted/Repressed)
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-zinc-500" />
                Baseline Neutral / Intergenic elements
              </div>
            </div>
          </div>

          {/* Pathway overactivation table */}
          <div className="p-5 bg-zinc-950/60 border border-zinc-900 rounded-2xl space-y-4">
            <div>
              <h3 className="text-sm font-display font-medium text-white flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-rose-500" />
                Subtype Signaling Pathway Overactivation
              </h3>
            </div>

            <div className="space-y-3">
              {enrichedPathways.map((p, idx) => (
                <div key={idx} className="p-3 bg-zinc-900/30 border border-zinc-805 rounded-xl flex items-center justify-between gap-4">
                  <div className="space-y-0.5 flex-1 min-w-0">
                    <div className="text-xs font-semibold text-zinc-100 truncate">{p.name}</div>
                    <div className="text-[10px] text-zinc-500 font-mono truncate">Evidence: {p.evidence}</div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0 font-mono text-xs">
                    <span className="text-[10px] text-zinc-400">{p.status}</span>
                    <div className="w-24 bg-zinc-800 rounded-full h-1.5 overflow-hidden">
                      <div className={`h-full ${p.color}`} style={{ width: `${p.percentage}%` }} />
                    </div>
                    <span className="text-zinc-300 font-bold w-8 text-right">{p.percentage}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right Side Bar cohort diagnostics */}
        <div className="space-y-6">
          
          <div className="glass-panel rounded-2xl p-5 space-y-4">
            <h3 className="text-xs font-mono text-purple-400 block uppercase">Cohort Frequency Statistics</h3>
            
            {loading ? (
              <div className="text-center py-8">
                <div className="w-6 h-6 border-2 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto" />
              </div>
            ) : activeCohortData ? (
              <div className="space-y-4">
                <div className="p-3 bg-zinc-950/60 rounded-xl border border-zinc-900">
                  <span className="text-zinc-500 text-[9px] font-mono block">Cohort Code Symbol</span>
                  <div className="text-lg font-bold text-white mt-1">TCGA-{selectedCohort}</div>
                  <div className="text-xs text-zinc-400 mt-0.5">{activeCohortData.name} ({activeCohortData.sampleCount} active cases)</div>
                </div>

                <div className="space-y-2 pt-2 border-t border-zinc-900">
                  <span className="text-zinc-500 text-[10px] font-mono uppercase block">Somatic Driver frequencies</span>
                  <div className="space-y-2">
                    {activeCohortData.driverFreqs.map((df, idx) => (
                      <div key={idx} className="space-y-1 text-xs font-mono">
                        <div className="flex justify-between text-zinc-350">
                          <span>{df.gene} Mutation</span>
                          <span className="text-pink-400">{df.pct}% of cases</span>
                        </div>
                        <div className="w-full bg-zinc-900 rounded-full h-1">
                          <div className="bg-pink-500 h-full" style={{ width: `${df.pct}%` }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : null}
          </div>

          <div className="glass-panel rounded-2xl p-5 space-y-3 font-mono text-[10px] text-zinc-500 shadow-md">
            <h4 className="text-xs font-semibold text-zinc-300 flex items-center gap-1 bg-zinc-950 p-2 rounded border border-zinc-900 font-sans">
              <Layers className="w-3.5 h-3.5 text-blue-400" />
              Volcano Analytics Note
            </h4>
            <p className="leading-relaxed font-sans text-zinc-500">
              The fold-change (X-axis) describes fold difference levels. The Y-axis values represent negative log10 p-values. Values &gt;4 indicate high-confidence statistical significance (typically validated via FDR correction algorithms).
            </p>
          </div>

        </div>

      </div>
    </div>
  );
}
