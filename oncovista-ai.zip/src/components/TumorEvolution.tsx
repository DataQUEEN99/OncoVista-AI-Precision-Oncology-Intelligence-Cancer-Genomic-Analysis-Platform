import React from "react";
import { ViewState, EvolutionPhase, EvolutionSimulation } from "../types";
import { Sliders, Zap, ShieldAlert, GitCommit, Dna, Info, Compass, Play } from "lucide-react";
import { BarChart, Bar, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { motion, AnimatePresence } from "motion/react";

interface EvolutionProps {
  activePatient: any | null;
  setView: (v: ViewState) => void;
}

export default function TumorEvolution({ activePatient, setView }: EvolutionProps) {
  const [activeWeekIndex, setActiveWeekIndex] = React.useState(0);
  const [simulationData, setSimulationData] = React.useState<EvolutionSimulation | null>(null);
  const [selectedRegimen, setSelectedRegimen] = React.useState("Standard-Osimertinib-Combo");
  const [loading, setLoading] = React.useState(false);

  const fetchSimulation = () => {
    setLoading(true);
    fetch(`/api/evolution/simulate?treatmentTrigger=${selectedRegimen}`)
      .then(res => res.json())
      .then(data => {
        setSimulationData(data);
        setLoading(false);
      })
      .catch(err => {
        console.error("Simulation retrieval errors:", err);
        setLoading(false);
      });
  };

  React.useEffect(() => {
    fetchSimulation();
  }, [selectedRegimen]);

  const activePhase: EvolutionPhase | null = simulationData 
    ? simulationData.clonalPhases[activeWeekIndex] 
    : null;

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-purple-400 uppercase tracking-widest flex items-center gap-2">
            <Compass className="w-3.5 h-3.5 animate-pulse" />
            Tumor Evolutionary Intelligence Sandbox
          </div>
          <h1 className="text-2xl font-display font-medium text-white tracking-tight mt-1">
            Clonal Evolution Simulator
          </h1>
          <p className="text-zinc-400 text-xs md:text-sm mt-1 max-w-2xl">
            Simulate tumor genomic drift under selection pressures of chemotherapy regimens and target inhibitors, and predict metastatic trajectories.
          </p>
        </div>

        {/* Therapy selector triggers */}
        <div className="flex gap-2">
          <select 
            value={selectedRegimen}
            onChange={(e) => {
              setSelectedRegimen(e.target.value);
              setActiveWeekIndex(0); // Reset timeline on reset
            }}
            className="bg-zinc-950 border border-zinc-950 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500 font-mono scale-95"
          >
            <option value="EGFR-directed-Osimertinib-monotherapy">Osimertinib 80mg Single Regimen</option>
            <option value="MAPK-cleavage-Combi-Dabrafenib-Trametinib">Dabrafenib+Trametinib Cascade Combo</option>
            <option value="Somatic-Adaptive-Basket-Protocols-NCT">Somatic Adaptive Basket Protocols</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Evolutionary Clonal Interactive Simulator */}
        <div className="lg:col-span-2 glass-panel rounded-2xl p-6 space-y-6 relative overflow-hidden">
          {/* Subtle decoration */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/5 rounded-full blur-[60px]" />
          
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-display font-medium text-white">Clonal Population Subpopulations</h3>
              <p className="text-[11px] text-zinc-500 font-mono">Therapy Pressure: {simulationData?.treatmentPressure}</p>
            </div>
            
            <div className="px-3 py-1.5 rounded-lg bg-purple-950/20 border border-purple-900/30 text-[10px] font-mono text-purple-400">
              {activePhase?.timepoint}
            </div>
          </div>

          {/* Timeline Slider with intervals */}
          <div className="p-4 bg-zinc-950/50 rounded-xl border border-zinc-900/80 space-y-3">
            <div className="flex justify-between text-[10px] font-mono text-zinc-500 uppercase">
              <span>Timeline: Week 0</span>
              <span>Week 4</span>
              <span>Week 12</span>
              <span>Week 24</span>
            </div>
            <input 
              type="range"
              min="0"
              max="3"
              step="1"
              value={activeWeekIndex}
              onChange={(e) => setActiveWeekIndex(parseInt(e.target.value))}
              className="w-full accent-purple-500 cursor-pointer h-2 bg-zinc-800 rounded-lg outline-none"
            />
            <div className="flex justify-between text-xs font-mono text-purple-400 font-bold">
              <span>Pre-Tx Baseline</span>
              <span>Induction Cycles</span>
              <span>Consolidation</span>
              <span>Clinical Escaped Recurrence</span>
            </div>
          </div>

          {/* Clonal Drift populations list */}
          <div className="space-y-4">
            <h4 className="text-xs font-mono text-zinc-400 uppercase tracking-widest">Active Mutant Genotypes</h4>

            {loading ? (
              <div className="text-center py-8">
                <div className="w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto" />
              </div>
            ) : activePhase ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {activePhase.clones.map((clone, idx) => (
                  <motion.div 
                    key={idx}
                    layout
                    initial={{ opacity: 0, scale: 0.97 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="p-4 rounded-xl bg-zinc-900/40 border border-zinc-800/80 space-y-3 relative group"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-display font-bold text-white flex items-center gap-1.5">
                        <GitCommit className="w-4 h-4 text-purple-400" />
                        {clone.name}
                      </span>
                      
                      <span className="text-sm font-display font-extrabold text-pink-400">
                        {clone.fraction}% population
                      </span>
                    </div>

                    <div className="w-full bg-zinc-950 h-1.5 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${clone.fraction}%` }}
                        className="bg-gradient-to-r from-neon-purple to-neon-pink h-full"
                        transition={{ duration: 0.4 }}
                      />
                    </div>

                    <div className="space-y-1.5 font-mono text-[10px]">
                      <div>
                        <span className="text-zinc-500 uppercase block text-[8px]">Clone genomic markers</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {clone.mutations.map((m, mIdx) => (
                            <span key={mIdx} className="px-1.5 py-0.5 rounded bg-purple-950/40 text-purple-300 border border-purple-900/40 text-[9px]">
                              {m}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="pt-2 border-t border-zinc-900/60 flex items-center justify-between text-zinc-400">
                        <span>SELECTIVE SENSITIVITY:</span>
                        <strong className="text-emerald-400 font-bold">{clone.sensitivity}</strong>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : null}
          </div>

          {/* Metastatic Chance indication banner */}
          {activePhase && (
            <div className="p-4 bg-rose-950/20 border border-rose-900/30 rounded-xl flex items-center justify-between gap-4 font-mono text-xs">
              <span className="text-zinc-400">CLONAL METASTASIS MIGRATION PROJECTION:</span>
              <strong className="text-rose-450 text-sm font-display font-medium text-rose-400">{activePhase.clonalMetastasisChance}</strong>
            </div>
          )}
        </div>

        {/* Right Side Column Metastatic predictions & projections */}
        <div className="space-y-6">
          
          {/* Metastatic Organ projections */}
          <div className="glass-panel rounded-2xl p-5 space-y-4">
            <div>
              <h4 className="text-xs font-mono text-purple-400 block uppercase">Bioinformatics Forecast</h4>
              <h3 className="text-sm font-display font-medium text-white">Organ Metastatic Probability</h3>
            </div>

            {simulationData ? (
              <div className="h-56 w-full text-xs font-mono">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={simulationData.metastaticProjections} layout="vertical" margin={{ top: 10, right: 10, left: 10, bottom: -10 }}>
                    <XAxis type="number" stroke="#52525b" domain={[0, 100]} />
                    <YAxis type="category" dataKey="organ" stroke="#52525b" width={80} />
                    <Tooltip contentStyle={{ backgroundColor: "#0e071c" }} />
                    <Bar dataKey="probability" fill="#ec4899" radius={[0, 4, 4, 0]}>
                      {simulationData.metastaticProjections.map((entry, idx) => (
                        <Cell key={`cell-${idx}`} fill={idx === 0 ? "#f43f5e" : idx === 1 ? "#a855f7" : "#3b82f6"} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : null}
          </div>

          <div className="p-5 bg-zinc-950 border border-zinc-900 rounded-2xl text-xs space-y-3 leading-relaxed">
            <h4 className="font-semibold text-zinc-300 flex items-center gap-1.5 font-sans">
              <Zap className="text-purple-400 w-4 h-4" />
              Treatment Selective Pressure
            </h4>
            
            <p className="text-zinc-500 font-sans text-xs">
              When applying single-target therapies like Osimertinib, sensitive cells (Founder clones harboring EGFR L858R) die off rapidly. However, clinical selection pressure causes resistant subclonal variants (such as secondary gatekeeper EGFR T790M) to proliferate, causing relapse.
            </p>
          </div>

        </div>

      </div>
    </div>
  );
}
