import React from "react";
import { motion } from "motion/react";

export default function BiotechHelix() {
  // Generate coordinates for structural nucleotides in a double helix
  const dotsCount = 20;
  const helixPoints = Array.from({ length: dotsCount }).map((_, idx) => {
    const angle = (idx / dotsCount) * Math.PI * 4; // Two full rotations
    const y = (idx / dotsCount) * 360 - 180;
    return { idx, angle, y };
  });

  return (
    <div className="relative w-full h-[380px] flex items-center justify-center overflow-hidden pointer-events-none select-none">
      {/* Background radial glow */}
      <div className="absolute w-72 h-72 rounded-full bg-violet-600/10 blur-[100px]" />
      <div className="absolute w-44 h-44 rounded-full bg-pink-500/10 blur-[80px]" />

      <svg className="w-full h-full max-w-sm" viewBox="-120 -200 240 400">
        {/* Connection bonds lines with motion animations */}
        {helixPoints.map((pt) => {
          const delay = pt.idx * 0.15;
          return (
            <g key={`bond-${pt.idx}`}>
              <motion.line
                x1={0}
                y1={pt.y}
                x2={0}
                y2={pt.y}
                stroke="url(#bondGradient)"
                strokeWidth="1.5"
                opacity="0.25"
                animate={{
                  x1: [Math.cos(pt.angle) * 75, Math.cos(pt.angle + Math.PI) * 75],
                  x2: [Math.cos(pt.angle + Math.PI) * 75, Math.cos(pt.angle) * 75],
                }}
                transition={{
                  repeat: Infinity,
                  repeatType: "reverse",
                  duration: 5,
                  ease: "easeInOut",
                  delay,
                }}
              />
            </g>
          );
        })}

        {/* Strand A (Neon Purple/Cyan) */}
        {helixPoints.map((pt) => {
          const delay = pt.idx * 0.15;
          return (
            <motion.circle
              key={`strandA-${pt.idx}`}
              cx={0}
              cy={pt.y}
              r={5 + (pt.idx % 3)}
              fill="#c084fc"
              filter="drop-shadow(0 0 6px rgba(168, 85, 247, 0.6))"
              animate={{
                cx: [Math.cos(pt.angle) * 75, Math.cos(pt.angle + Math.PI) * 75],
                scale: [0.8, 1.2, 0.8],
                opacity: [0.4, 0.9, 0.4],
              }}
              transition={{
                repeat: Infinity,
                repeatType: "reverse",
                duration: 5,
                ease: "easeInOut",
                delay,
              }}
            />
          );
        })}

        {/* Strand B (Neon Pink/Blue) */}
        {helixPoints.map((pt) => {
          const delay = pt.idx * 0.15;
          return (
            <motion.circle
              key={`strandB-${pt.idx}`}
              cx={0}
              cy={pt.y}
              r={5 + ((pt.idx + 1) % 3)}
              fill="#f472b6"
              filter="drop-shadow(0 0 6px rgba(244, 114, 182, 0.6))"
              animate={{
                cx: [Math.sin(pt.angle + Math.PI) * 75, Math.sin(pt.angle) * 75],
                scale: [1.2, 0.8, 1.2],
                opacity: [0.9, 0.4, 0.9],
              }}
              transition={{
                repeat: Infinity,
                repeatType: "reverse",
                duration: 5,
                ease: "easeInOut",
                delay,
              }}
            />
          );
        })}

        {/* Definition gradients */}
        <defs>
          <linearGradient id="bondGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#a855f7" />
            <stop offset="50%" stopColor="#3b82f6" />
            <stop offset="100%" stopColor="#ec4899" />
          </linearGradient>
        </defs>
      </svg>

      {/* Futuristic Floating Genome Tags */}
      <div className="absolute top-10 left-6 flex flex-col gap-1 text-[10px] font-mono text-zinc-500">
        <span>DNA_STRAND_SEQ_A :: OK</span>
        <span className="text-purple-400">ALIGNMENT_VAF_LOCK : 99.8%</span>
      </div>
      <div className="absolute bottom-10 right-6 flex flex-col gap-1 text-[10px] font-mono text-zinc-500 text-right">
        <span>COHORT::TCGA-LUAD-E001</span>
        <span className="text-pink-400">CHROM::X_Y_Splicing</span>
      </div>
    </div>
  );
}
