import React from "react";
import { Patient, ViewState } from "../types";
import { Pill, Activity, ExternalLink, ShieldCheck, Microscope, Info, Search } from "lucide-react";
import { motion } from "motion/react";

interface TherapyProps {
  patients: Patient[];
  activePatient: Patient | null;
  setView: (v: ViewState) => void;
}

export default function TherapyRecommendation({ patients, activePatient, setView }: TherapyProps) {
  const [searchTerm, setSearchTerm] = React.useState(activePatient?.mutations?.[0]?.gene || "");
  
  const trialMatches = [
    { gene: "EGFR", mutation: "L858R / Exon 19 del", drug: "Osimertinib 80mg Daily", pathway: "EGFR Tyrosine Kinase Pathway", trialId: "NCT03511144", trialName: "FLAURA2 Combos", phase: "Phase III", status: "Recruiting", description: "First-line Osimertinib combined with intensive pemetrexed/platinum chemotherapy cycles for stage IV non-small cell lung adenocarcinomas." },
    { gene: "BRAF", mutation: "V600E", drug: "Dabrafenib (Tafinlar) + Trametinib (Mekinist)", pathway: "MAPK Signaling Transduction", trialId: "NCT02034110", trialName: "COMBI-v Trials", phase: "Phase III", status: "Completed", description: "Comparison of dabrafenib and trametinib combination therapy versus vemurafenib monotherapy in cutaneous melanoma mutation targets." },
    { gene: "BRCA1", mutation: "C61G / DNA Repair Defect", drug: "Olaparib (Lynparza)", pathway: "Homologous Recombination DDR", trialId: "NCT02000622", trialName: "POLO Target Studies", phase: "Phase III", status: "Active, Not Recruiting", description: "Olaparib maintenance therapy for germline BRCA-mutated cancer patients following first-line platinum-based regimens." },
    { gene: "KRAS", mutation: "G12C Point Mutation", drug: "Sotorasib (Lumakras)", pathway: "RAS Complex Switch GTP/GDP", trialId: "NCT04625647", trialName: "CodeBreaK-200", phase: "Phase III", status: "Enrolling", description: "Evaluating structural covalent inhibitors targeting mutant codon 12 cysteine transitions block to counter persistent proliferation." },
    { gene: "PIK3CA", mutation: "E545K Activating", drug: "Alpelisib (Piqray) + Fulvestrant", pathway: "PI3K/AKT/mTOR Pathway", trialId: "NCT02437357", trialName: "SOLAR-1 Phase III", phase: "Phase III", status: "Completed", description: "Alpelisib combined with hormone therapies for pretreated HR+/HER2- PIK3CA mutated metastatic breast carcinomas." },
  ];

  const searchFiltered = trialMatches.filter(t => 
    t.gene.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.pathway.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.trialName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-purple-400 uppercase tracking-widest flex items-center gap-2">
            <Pill className="w-3.5 h-3.5" />
            Therapeutic Decision Matcher
          </div>
          <h1 className="text-2xl font-display font-medium text-white tracking-tight mt-1">
            Precision Therapy Recommendations
          </h1>
          <p className="text-zinc-400 text-xs md:text-sm mt-1 max-w-2xl">
            Map identified patient mutations to approved pharmacological inhibitors, molecular bypass models, and active recruiting Phase III clinical trials.
          </p>
        </div>

        {activePatient && (
          <div className="flex items-center gap-1.5 p-1 bg-zinc-950 border border-zinc-900 rounded-xl">
            <button 
              onClick={() => setSearchTerm(activePatient.mutations?.[0]?.gene || "")}
              className="px-3 py-1.5 text-[10px] font-mono rounded-lg bg-purple-900/30 border border-purple-800 text-purple-300"
            >
              Filter by {activePatient.name}'s mutations
            </button>
          </div>
        )}
      </div>

      {/* SEARCH CARD */}
      <div className="p-4 bg-zinc-950/80 border border-zinc-900 rounded-2xl flex flex-col md:flex-row items-center gap-4">
        <div className="relative w-full">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
          <input 
            type="text"
            placeholder="Search matching pharmacological profiles by gene symbol (e.g. EGFR, TP53, MAPK)..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-zinc-900/40 border border-zinc-800 rounded-xl py-2 pl-9 pr-4 text-xs text-white focus:outline-none focus:border-purple-500"
          />
        </div>
        {searchTerm && (
          <button 
            onClick={() => setSearchTerm("")}
            className="text-xs font-mono text-pink-400 hover:text-white shrink-0"
          >
            Clear Filter
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Columns: Targeted recommendation cards */}
        <div className="lg:col-span-2 space-y-4">
          
          {searchFiltered.length === 0 ? (
            <div className="text-center py-16 bg-zinc-950/20 border border-zinc-900 rounded-2xl text-zinc-500 space-y-2">
              <Microscope className="w-10 h-10 mx-auto text-zinc-700" />
              <div className="text-xs font-mono">No specific clinical matches found in this sub-database.</div>
              <p className="text-[11px] text-zinc-650 max-w-xs mx-auto">
                Try searching standard drivers like EGFR, BRAF, BRCA1 or PIK3CA to view clinical matched trial templates.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {searchFiltered.map((t, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="p-5 glass-panel rounded-2xl space-y-4 relative overflow-hidden"
                >
                  {/* Subtle top decoration */}
                  <div className="absolute top-0 left-0 w-full h-[1.5px] bg-gradient-to-r from-purple-500 via-pink-500 to-blue-500" />
                  
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 pb-3 border-b border-zinc-900">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded bg-purple-950/40 text-purple-300 font-mono text-[9px] font-bold border border-purple-850">
                          {t.gene} DIRECTED
                        </span>
                        <span className="text-xs text-zinc-400 font-mono">[{t.mutation}]</span>
                      </div>
                      <h3 className="text-base font-display font-medium text-white mt-1.5">{t.drug}</h3>
                    </div>

                    <div className="flex flex-col items-start md:items-end font-mono text-[10px]">
                      <span className="text-purple-400 font-bold">{t.trialId}</span>
                      <span className="text-zinc-500">{t.trialName}</span>
                    </div>
                  </div>

                  <p className="text-xs leading-relaxed text-zinc-400">
                    {t.description}
                  </p>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-3.5 border-t border-zinc-900 text-[10px] font-mono">
                    <div>
                      <span className="text-zinc-500 block uppercase">Biology Pathway</span>
                      <strong className="text-zinc-300 font-normal">{t.pathway}</strong>
                    </div>
                    <div>
                      <span className="text-zinc-500 block uppercase">Regimen Trial Phase</span>
                      <strong className="text-purple-400">{t.phase}</strong>
                    </div>
                    <div>
                      <span className="text-zinc-500 block uppercase">Enrollment Status</span>
                      <span className="px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400">{t.status}</span>
                    </div>
                    <div className="flex items-end justify-end">
                      <a 
                        href={`https://clinicaltrials.gov/study/${t.trialId}`}
                        target="_blank" 
                        referrerPolicy="no-referrer"
                        className="text-pink-400 hover:text-white flex items-center gap-1 hover:underline cursor-pointer"
                      >
                        Registry Link <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}

        </div>

        {/* Right Side Column: Molecular Oncology Board Guidelines */}
        <div className="space-y-6">
          
          {activePatient && (
            <div className="p-5 bg-gradient-to-b from-purple-950/20 to-zinc-950/40 border border-purple-900/30 rounded-2xl space-y-4">
              <h3 className="text-xs font-mono font-bold text-purple-300 uppercase tracking-widest flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-purple-400" />
                Somatic Mapping: {activePatient.name}
              </h3>
              
              <div className="space-y-3 text-xs leading-relaxed text-zinc-400">
                <p>
                  Based upon identified mutation variants in <strong className="text-white">{activePatient.mutations.map(m => m.gene).join(", ")}</strong>, clinical guidelines suggest standard evaluation of inhibitors.
                </p>
                <p className="text-zinc-500">
                  Targeted therapy achieves higher objective response rates (ORR) and progression-free survival (PFS) in driver positive mutations compared to standard chemotherapy pipelines.
                </p>
              </div>

              <div className="pt-3 border-t border-zinc-900">
                <button 
                  onClick={() => setView("reports")}
                  className="w-full py-2 bg-purple-600 hover:bg-purple-750 text-xs font-semibold text-white rounded-xl shadow-md cursor-pointer transition-colors"
                >
                  Generate Diagnostic Report
                </button>
              </div>
            </div>
          )}

          <div className="glass-panel rounded-2xl p-5 space-y-4 text-xs font-mono">
            <h3 className="text-sm font-display font-medium text-white flex items-center gap-2 font-sans">
              <Info className="w-4 h-4 text-purple-400" animate-pulse />
              NCCN Drug Combination Guideline
            </h3>
            
            <p className="text-zinc-400 leading-relaxed font-sans text-xs">
              Oncologists must look out for genetic co-mutations which frequently trigger rapid resistance bypass lines. 
            </p>

            <ul className="space-y-2 text-[10px] text-zinc-500 pl-4 list-disc leading-relaxed">
              <li>Dual EGFR mutation + MET amplification creates Osimertinib drug failure.</li>
              <li>BRAF V600E inhibitors require auxiliary MEK target inhibition to avoid paradox MAPK cascade activation.</li>
              <li>TP53 somatic mutations typically diminish responses to PARP clearing inhibitors.</li>
            </ul>
          </div>

        </div>

      </div>
    </div>
  );
}
