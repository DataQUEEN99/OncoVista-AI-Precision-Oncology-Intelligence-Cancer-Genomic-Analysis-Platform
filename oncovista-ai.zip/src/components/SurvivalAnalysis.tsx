import React from "react";
import { ViewState } from "../types";
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, ReferenceLine, AreaChart, Area } from "recharts";
import { HelpCircle, Sparkles, TrendingDown, Info, ShieldAlert, Layers } from "lucide-react";
import { motion } from "motion/react";

interface SurvivalProps {
  setView: (v: ViewState) => void;
}

interface PlotPoint {
  month: number;
  survivalPct: number;
}

export default function SurvivalAnalysis({ setView }: SurvivalProps) {
  const [selectedDiagnosis, setSelectedDiagnosis] = React.useState("LUAD");
  const [loading, setLoading] = React.useState(false);
  
  const [wildtypeData, setWildtypeData] = React.useState<PlotPoint[]>([]);
  const [mutatedData, setMutatedData] = React.useState<PlotPoint[]>([]);
  
  const [wildtypeStats, setWildtypeStats] = React.useState({ medianMonths: 48, hazardRatio: 1.0 });
  const [mutatedStats, setMutatedStats] = React.useState({ medianMonths: 22, hazardRatio: 1.84 });

  const fetchSurvivalCurves = async () => {
    setLoading(true);
    try {
      // 1. Fetch wildtype curve
      const wtRes = await fetch(`/api/survival-plot?diagnosis=${selectedDiagnosis}&mutationGroup=wildtype`);
      const wtData = await wtRes.json();
      setWildtypeData(wtData.survivalData);
      setWildtypeStats({
        medianMonths: wtData.medianSurvivalMonths,
        hazardRatio: wtData.hazardRatio
      });

      // 2. Fetch mutated curve (recurrent driver positive)
      const mutRes = await fetch(`/api/survival-plot?diagnosis=${selectedDiagnosis}&mutationGroup=mutated`);
      const mutData = await mutRes.json();
      setMutatedData(mutData.survivalData);
      setMutatedStats({
        medianMonths: mutData.medianSurvivalMonths,
        hazardRatio: mutData.hazardRatio
      });

    } catch (err) {
      console.error("Survival metrics load failures:", err);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchSurvivalCurves();
  }, [selectedDiagnosis]);

  // Combine datasets for Recharts
  const chartData = React.useMemo(() => {
    if (wildtypeData.length === 0) return [];
    return wildtypeData.map((wt, idx) => {
      const mut = mutatedData[idx] || { survivalPct: 100 };
      return {
        month: wt.month,
        "Wild-Type / Responder Cohort": wt.survivalPct,
        "Mutant Driver / Resistant Cohort": mut.survivalPct
      };
    });
  }, [wildtypeData, mutatedData]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-purple-400 uppercase tracking-widest flex items-center gap-2">
            <TrendingDown className="w-3.5 h-3.5" />
            TCGA Cohort Clinical Outcomes
          </div>
          <h1 className="text-2xl font-display font-medium text-white tracking-tight mt-1">
            Kaplan-Meier Survival Analyzer
          </h1>
          <p className="text-zinc-400 text-xs md:text-sm mt-1 max-w-2xl">
            Evaluate longitudinal patient survival probability rates segmenting by clinical diagnosis and driver-mutation presence.
          </p>
        </div>

        {/* Diagnosis Selector */}
        <div className="flex bg-zinc-950 border border-zinc-900 rounded-xl p-1 text-xs font-mono self-start md:self-center">
          {[
            { id: "LUAD", label: "LUAD (Lung Adenocarcinoma)" },
            { id: "SKCM", label: "SKCM (Melanoma)" },
            { id: "BRCA", label: "BRCA (Breast)" },
            { id: "COAD", label: "COAD (Colorectal)" }
          ].map((item) => (
            <button 
              key={item.id}
              onClick={() => setSelectedDiagnosis(item.id)}
              className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                selectedDiagnosis === item.id 
                  ? "bg-purple-600 text-white font-bold" 
                  : "text-zinc-400 hover:text-white"
              }`}
            >
              {item.id}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Kaplan-Meier Plot Container */}
        <div className="lg:col-span-2 glass-panel rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-display font-medium text-white">Kaplan-Meier Curve Projections</h3>
              <p className="text-[11px] text-zinc-500 font-mono">Cohort parameter: {selectedDiagnosis} somatic sequence profile</p>
            </div>
            {loading && <div className="text-xs text-purple-400 font-mono animate-pulse">Recalculating curves...</div>}
          </div>

          <div className="h-80 w-full mt-4 text-xs font-mono">
            {chartData.length > 0 && (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <XAxis dataKey="month" stroke="#52525b" label={{ value: "Survival Interval (Months)", position: "insideBottom", offset: -5, fill: "#71717a" }} />
                  <YAxis stroke="#52525b" domain={[0, 100]} label={{ value: "Survival Probability %", angle: -90, position: "insideLeft", offset: 15, fill: "#71717a" }} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#0e071c", borderColor: "#a855f7" }}
                    formatter={(value) => [`${value}% Survival`]}
                  />
                  <Legend verticalAlign="top" height={36}/>
                  
                  {/* Wildtype Area */}
                  <Area 
                    type="monotone" 
                    dataKey="Wild-Type / Responder Cohort" 
                    stroke="#10b981" 
                    fill="rgba(16, 185, 129, 0.03)"
                    strokeWidth={2.5} 
                  />
                  {/* Mutated Area */}
                  <Area 
                    type="monotone" 
                    dataKey="Mutant Driver / Resistant Cohort" 
                    stroke="#f43f5e" 
                    fill="rgba(244, 63, 94, 0.03)" 
                    strokeWidth={2.5}
                    strokeDasharray="4 4"
                  />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>

          {/* Quick instructions */}
          <div className="flex items-start gap-2.5 bg-zinc-950/40 p-4 rounded-xl border border-zinc-900 text-xs text-zinc-500 leading-relaxed font-sans">
            <Info className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
            <p>
              The plot displays survival proportions over a 60-month window. The dotted red line highlights a significant decrement in survival margins for patents with high-frequency pathogenic mutations in drivers like TP53, KRAS, and BRAF within the selected cohort category.
            </p>
          </div>
        </div>

        {/* Hazard Grid & Statistics */}
        <div className="space-y-6">
          
          <div className="glass-panel rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-display font-medium text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-purple-400" />
              Cohort Cox Hazard Ratios
            </h3>

            <div className="space-y-3 font-mono text-xs">
              <div className="p-3 bg-zinc-950/60 rounded-xl border border-zinc-900 space-y-1">
                <span className="text-zinc-500 uppercase text-[9px] block">Log-Rank Test Significance</span>
                <div className="text-base text-white font-bold flex items-center justify-between">
                  <span>p-Value Score</span>
                  <span className="text-purple-400">p &lt; 0.0015 (High)</span>
                </div>
              </div>

              <div className="p-3 bg-zinc-950/60 rounded-xl border border-zinc-900 space-y-1">
                <span className="text-zinc-500 uppercase text-[9px] block">Calculated Hazard Ratio (HR)</span>
                <div className="text-base text-white font-bold flex items-center justify-between">
                  <span>Relative Risk</span>
                  <span className="text-rose-400">{mutatedStats.hazardRatio}x Risk</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-center text-[11px]">
                <div className="p-3 bg-zinc-950/60 rounded-xl border border-zinc-900">
                  <span className="text-zinc-500 block uppercase text-[8px]">WT Median Survival</span>
                  <strong className="text-emerald-400 text-sm font-display font-bold block mt-1">{wildtypeStats.medianMonths} Mos</strong>
                </div>
                <div className="p-3 bg-zinc-950/60 rounded-xl border border-zinc-900">
                  <span className="text-zinc-500 block uppercase text-[8px]">Mut Median Survival</span>
                  <strong className="text-rose-400 text-sm font-display font-bold block mt-1">{mutatedStats.medianMonths} Mos</strong>
                </div>
              </div>
            </div>
          </div>

          <div className="p-5 bg-gradient-to-br from-purple-950/20 to-zinc-950 border border-purple-900/30 rounded-2xl space-y-3 text-xs leading-relaxed">
            <h4 className="text-xs font-mono font-bold text-purple-300 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-purple-400" />
              Clinical Application Insights
            </h4>
            <p className="text-zinc-400 leading-relaxed font-sans">
              Cohorts harboring co-mutations demonstrate a steep, early drop-off in survival indices, emphasizing the value of combination therapies (e.g. EGFR-inhibitors with checkpoint inhibitors) to stave off clonal escape.
            </p>
          </div>

        </div>

      </div>
    </div>
  );
}
