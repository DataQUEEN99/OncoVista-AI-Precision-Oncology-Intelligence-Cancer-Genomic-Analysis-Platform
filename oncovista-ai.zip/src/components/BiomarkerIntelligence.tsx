import React from "react";
import { BiomarkerPair, ViewState } from "../types";
import { ShieldCheck, Layers, Award, Radio, Star, Info, AlertTriangle, BookOpen } from "lucide-react";
import { motion } from "motion/react";

interface BiomarkerProps {
  setView: (v: ViewState) => void;
}

export default function BiomarkerIntelligence({ setView }: BiomarkerProps) {
  const [dbBiomarkers, setDbBiomarkers] = React.useState<BiomarkerPair[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [selectedTier, setSelectedTier] = React.useState("All");

  React.useEffect(() => {
    fetch("/api/biomarkers")
      .then(res => res.json())
      .then(data => {
        setDbBiomarkers(data);
        setLoading(false);
      })
      .catch(err => {
        console.error("Biomarker load failed:", err);
        setLoading(false);
      });
  }, []);

  const filteredBiomarkers = dbBiomarkers.filter(b => 
    selectedTier === "All" || b.tier.includes(selectedTier)
  );

  return (
    <div className="space-y-6">
      {/* Title Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-purple-400 uppercase tracking-widest flex items-center gap-2">
            <Award className="w-3.5 h-3.5" />
            Precision Genomics Knowledgebase
          </div>
          <h1 className="text-2xl font-display font-medium text-white tracking-tight mt-1">
            Biomarker Intelligence Hub
          </h1>
          <p className="text-zinc-400 text-xs md:text-sm mt-1 max-w-2xl">
            Examine validated somatic alterations mapped against regulatory tiers, clinical evidence profiles, and pharmacological response records.
          </p>
        </div>

        {/* Tier filter */}
        <div className="flex gap-1.5 p-1 bg-zinc-950/60 border border-zinc-805 rounded-xl text-xs font-mono self-start md:self-center">
          {["All", "Tier IA", "Tier IB", "Clinical"].map((tier) => (
            <button 
              key={tier}
              onClick={() => setSelectedTier(tier)}
              className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                (tier === "All" && selectedTier === "All") || (tier !== "All" && selectedTier.includes(tier))
                  ? "bg-purple-600 text-white font-bold" 
                  : "text-zinc-400 hover:text-white"
              }`}
            >
              {tier}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="text-center py-20">
          <div className="w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-zinc-400 text-xs font-mono mt-2">Loading biomarker intelligence references...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Main List */}
          <div className="lg:col-span-2 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredBiomarkers.map((b, idx) => {
                const isFdaTier = b.tier.includes("IA") || b.tier.includes("IB");
                return (
                  <motion.div 
                    key={idx}
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: idx * 0.04 }}
                    className="p-5 glass-panel glass-panel-hover rounded-2xl flex flex-col justify-between"
                  >
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase tracking-wider bg-purple-950/40 text-purple-300 border border-purple-900/50">
                          {b.gene} VARIANT
                        </span>
                        
                        <span className={`px-2 py-0.5 rounded text-[8px] font-mono uppercase tracking-wider ${
                          isFdaTier 
                            ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
                            : "bg-blue-500/10 text-blue-400 border border-blue-500/20"
                        }`}>
                          {b.tier}
                        </span>
                      </div>

                      <div className="space-y-1">
                        <h3 className="text-sm font-semibold text-zinc-100">{b.mutation}</h3>
                        <p className="text-[11px] font-mono text-zinc-500">Sensitive to: <strong className="text-zinc-300">{b.agent}</strong></p>
                      </div>

                      <div className="text-xs text-zinc-400 leading-relaxed bg-zinc-950/40 p-3 rounded-xl border border-zinc-900 font-sans">
                        <span className="font-mono text-[9px] text-zinc-500 block uppercase mb-0.5">Clinical Trial Evidence</span>
                        {b.evidence}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 mt-4 pt-3 border-t border-zinc-900">
                      <Radio className="w-3.5 h-3.5 text-pink-400" />
                      <div className="text-[10px] text-zinc-500 font-mono">
                        EXPECTED RESPONSE: 
                        <strong className="text-emerald-400 uppercase font-bold ml-1">{b.response}</strong>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Guidelines and evidence tiers */}
          <div className="space-y-6">
            <div className="glass-panel rounded-2xl p-5 space-y-4 text-xs">
              <h3 className="text-sm font-display font-medium text-white flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-purple-400" />
                Evidence Rating Protocol
              </h3>
              
              <p className="text-zinc-400 leading-relaxed">
                Biomarkers inside OncoVista AI are grouped following joint consensus guidelines of AMP / ASCO / CAP for cancer somatic variant interpretation:
              </p>

              <div className="space-y-4 pt-4 border-t border-zinc-900 text-zinc-400 font-mono text-[10px]">
                <div className="space-y-1">
                  <span className="text-emerald-400 font-bold block uppercase flex items-center gap-1">
                    <Star className="w-3 h-3 fill-emerald-400" />
                    Tier IA : Strong Clinical Significance
                  </span>
                  <p className="text-zinc-500 font-sans ml-4 pl-1 border-l border-zinc-850">
                    FDA-approved diagnostic therapies or diagnostic guidelines included standard of care recommendations inside oncology targets.
                  </p>
                </div>

                <div className="space-y-1">
                  <span className="text-blue-400 font-bold block uppercase flex items-center gap-1">
                    <Layers className="w-3 h-3 text-blue-400" />
                    Tier IB : Potential Significance
                  </span>
                  <p className="text-zinc-500 font-sans ml-4 pl-1 border-l border-zinc-850">
                    Strong clinical validation backed by well-designed phase II trial outcomes or expert consensus.
                  </p>
                </div>

                <div className="space-y-1">
                  <span className="text-purple-400 font-bold block uppercase flex items-center gap-1">
                    <BookOpen className="w-3 h-3 text-purple-400" />
                    Tier IIC : Off-Label / Clinical Trial
                  </span>
                  <p className="text-zinc-500 font-sans ml-4 pl-1 border-l border-zinc-850">
                    Approved drugs for different tumor indications or active patient inclusions inside basket testing trials.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-4 bg-zinc-950/80 border border-zinc-900 rounded-2xl flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />
              <p className="text-[10px] text-zinc-500 leading-snug">
                Warning: Clinicians should always consult molecular tumor boards before transitioning therapy protocols based upon transient genetic sequencing data alone.
              </p>
            </div>
          </div>

        </div>
      )}
    </div>
  );
}
