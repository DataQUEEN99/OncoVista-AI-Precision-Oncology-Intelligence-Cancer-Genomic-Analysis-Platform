import React from "react";
import { Patient, ViewState } from "../types";
import { motion } from "motion/react";
import { 
  Dna, 
  Activity, 
  TrendingUp, 
  ShieldAlert, 
  Search, 
  Users, 
  Clock, 
  CheckCircle,
  FileText,
  UserCheck,
  ChevronRight
} from "lucide-react";
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  PieChart, 
  Pie, 
  Cell, 
  AreaChart, 
  Area 
} from "recharts";

interface DashboardProps {
  patients: Patient[];
  activePatient: Patient | null;
  setActivePatient: (p: Patient) => void;
  setView: (v: ViewState) => void;
}

export default function DashboardOverview({ patients, activePatient, setActivePatient, setView }: DashboardProps) {
  const [searchTerm, setSearchTerm] = React.useState("");

  // Filter patients based on Search Term
  const filteredPatients = patients.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.diagnosis.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Compute stats across patients
  const totalMutations = patients.reduce((acc, p) => acc + p.mutations.length, 0);
  const totalDrivers = patients.reduce((acc, p) => {
    const drivers = p.mutations.filter(m => ["Pathogenic", "Likely Pathogenic"].includes(m.pathogenicity)).length;
    return acc + drivers;
  }, 0);
  const avgTumorBurden = (patients.reduce((acc, p) => acc + p.tumorBurden, 0) / patients.length).toFixed(1);
  const maxRisk = Math.max(...patients.map(p => p.riskScore));

  // Visual Pathway Distribution Data for active patient or aggregated
  const pathwayData = activePatient 
    ? activePatient.mutations.map(m => {
        let path = "MAPK Cycle";
        if (["EGFR", "KRAS", "BRAF"].includes(m.gene)) path = "RAS-MAPK Cascade";
        else if (["PIK3CA"].includes(m.gene)) path = "PI3K-AKT-mTOR";
        else if (["BRCA1"].includes(m.gene)) path = "DNA Damage Response";
        else if (["TP53"].includes(m.gene)) path = "Cell Cycle Checkpoint";
        else if (["APC"].includes(m.gene)) path = "Wnt-BetaCatenin";
        return { name: m.gene, val: m.depth, pathway: path };
      })
    : [
        { name: "TP53", val: 85, pathway: "Cell Cycle Checkpoint" },
        { name: "EGFR", val: 72, pathway: "RAS-MAPK Cascade" },
        { name: "KRAS", val: 64, pathway: "RAS-MAPK Cascade" },
        { name: "BRCA1", val: 45, pathway: "DNA Damage DDR" },
        { name: "PIK3CA", val: 38, pathway: "PI3K-AKT-mTOR" },
        { name: "APC", val: 56, pathway: "Wnt-BetaCatenin" }
      ];

  const mutationBurdenChartData = patients.map(p => ({
    name: p.id,
    Burden: p.tumorBurden,
    Risk: p.riskScore,
    nameFull: p.name
  }));

  const COLORS = ["#a855f7", "#3b82f6", "#ec4899", "#22c55e", "#eab308", "#f43f5e"];

  return (
    <div className="space-y-6">
      {/* Top Welcome Title Grid */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 glass-panel rounded-2xl relative overflow-hidden">
        {/* Background ambient lighting */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-purple-400 uppercase tracking-widest">
            <span className="w-2 h-2 rounded-full bg-purple-500 animate-pulse" />
            Precision Genomics Workspace Live
          </div>
          <h1 className="text-2xl md:text-3xl font-display font-medium text-white tracking-tight mt-1">
            Genomics Intelligence Dashboard
          </h1>
          <p className="text-zinc-400 text-xs md:text-sm mt-1 max-w-2xl">
            Select patient genomes to annotate somatic mutations, simulate clonal evolution resistance paths, and match targeted FDA oncology drug pipelines.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setView("upload")}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-gradient-to-r from-neon-purple to-neon-pink text-white hover:opacity-90 shadow-lg shadow-purple-500/20 active:scale-95 transition-transform cursor-pointer"
          >
            + Upload Somatic Panel
          </button>
        </div>
      </div>

      {/* Grid Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {[
          { label: "Sequenced Patients", val: patients.length, unit: "cohorts", icon: Users, color: "text-blue-400", bg: "bg-blue-500/10" },
          { label: "Total Somatic Mutations", val: totalMutations, unit: "variants", icon: Dna, color: "text-purple-400", bg: "bg-purple-500/10" },
          { label: "FDA Matched Biomarkers", val: 8, unit: "pairs", icon: CheckCircle, color: "text-pink-400", bg: "bg-pink-500/10" },
          { label: "Average TMB Ratio", val: avgTumorBurden, unit: "mut/Mb", icon: TrendingUp, color: "text-emerald-400", bg: "bg-emerald-500/10" },
          { label: "Max Risk Index", val: `${maxRisk}%`, unit: "High Critical", icon: ShieldAlert, color: "text-rose-400", bg: "bg-rose-500/10" }
        ].map((card, idx) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="p-4 glass-panel rounded-2xl flex flex-col justify-between relative group overflow-hidden"
          >
            <div className={`p-2 rounded-xl w-fit ${card.bg} ${card.color} mb-3`}>
              <card.icon className="w-5 h-5" />
            </div>
            <div>
              <div className="text-2xl font-display font-bold text-white group-hover:scale-105 transition-transform origin-left">{card.val}</div>
              <div className="text-[10px] text-zinc-500 font-mono uppercase tracking-wide mt-1">{card.label}</div>
              <div className="text-[10px] text-zinc-400 mt-0.5">{card.unit}</div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Main Grid Content Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Side Column: Active Patient Selector & Full Cohort */}
        <div className="glass-panel rounded-2xl p-5 flex flex-col space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-display font-medium text-white flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-purple-400" />
              Patient Cohort Roster ({filteredPatients.length})
            </h2>
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
            <input 
              type="text"
              placeholder="Search by ID, Name or Diagnosis..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-zinc-950/40 border border-zinc-800 rounded-xl py-2 pl-9 pr-4 text-xs text-white focus:outline-none focus:border-purple-500 transition-colors"
            />
          </div>

          {/* Patient Scrollable List */}
          <div className="space-y-2 max-h-[350px] overflow-y-auto pr-1">
            {filteredPatients.map(p => {
              const isActive = activePatient?.id === p.id;
              return (
                <div 
                  key={p.id}
                  onClick={() => setActivePatient(p)}
                  className={`p-3.5 rounded-xl cursor-pointer transition-all flex items-center justify-between border ${
                    isActive 
                      ? "bg-purple-950/20 border-purple-500/50 shadow-md shadow-purple-500/5" 
                      : "bg-zinc-950/20 border-zinc-900 hover:border-purple-900/40 hover:bg-zinc-900/30"
                  }`}
                >
                  <div className="space-y-1.5 flex-1 min-w-0 pr-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold font-mono text-white">{p.id}</span>
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-mono font-medium ${
                        p.riskClassification === "High" 
                          ? "bg-rose-500/10 text-rose-400" 
                          : p.riskClassification === "Intermediate"
                            ? "bg-amber-500/10 text-amber-400"
                            : "bg-emerald-500/10 text-emerald-400"
                      }`}>
                        Risk {p.riskScore}%
                      </span>
                    </div>
                    <div className="text-xs font-medium text-zinc-300 truncate">{p.name}</div>
                    <div className="text-[10px] text-zinc-500 font-mono truncate">{p.diagnosis}</div>
                  </div>
                  
                  <div className="flex flex-col items-end gap-1.5 shrink-0">
                    <span className="text-[9px] font-mono text-zinc-400">{p.stage}</span>
                    <span className={`w-2 h-2 rounded-full ${
                      p.status === "Active" ? "bg-purple-500 shadow-[0_0_6px_#a855f7]" :
                      p.status === "Stable" ? "bg-blue-500" :
                      p.status === "Progression" ? "bg-rose-500 animate-pulse" : "bg-emerald-500"
                    }`} title={`Status: ${p.status}`} />
                    <ChevronRight className="w-3.5 h-3.5 text-zinc-600" />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-2 border-t border-zinc-900 text-center">
            <p className="text-[10px] font-mono text-zinc-500">
              Double-click any patient profile to open advanced Evolution timelines.
            </p>
          </div>
        </div>

        {/* Right 2 Columns: Genomic Insight Visualization Panels */}
        <div className="lg:col-span-2 space-y-6">

          {/* Selected Patient Mini Summary */}
          {activePatient && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-5 glass-panel rounded-2xl relative overflow-hidden"
            >
              {/* Corner neon effect */}
              <div className="absolute top-0 right-0 w-2 h-full bg-gradient-to-b from-purple-500 to-pink-500" />
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2 space-y-1">
                  <div className="text-[10px] font-mono text-pink-400 uppercase tracking-widest flex items-center gap-1">
                    <Activity className="w-3.5 h-3.5" />
                    Target Genotyping Active Case
                  </div>
                  <h3 className="text-lg font-display font-medium text-white mt-1">{activePatient.name}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-3 pt-3 border-t border-zinc-900 text-xs text-zinc-400">
                    <div>
                      <span className="font-mono text-[9px] block text-zinc-500 uppercase">Age / Gender</span>
                      <strong className="text-zinc-200">{activePatient.age} yrs / {activePatient.gender}</strong>
                    </div>
                    <div>
                      <span className="font-mono text-[9px] block text-zinc-500 uppercase">Clinical Stage</span>
                      <strong className="text-zinc-200">{activePatient.stage}</strong>
                    </div>
                    <div>
                      <span className="font-mono text-[9px] block text-zinc-500 uppercase">Tumor Burden TMB</span>
                      <strong className="text-zinc-200 text-purple-400">{activePatient.tumorBurden} mut/Mb</strong>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-center justify-center p-3 bg-zinc-950/40 border border-zinc-800 rounded-xl relative">
                  <span className="text-[9px] font-mono text-zinc-500 uppercase absolute top-2">AI Aggression Score</span>
                  <div className="text-3xl font-display font-medium text-purple-400 mt-2">{activePatient.riskScore}%</div>
                  <span className={`text-[10px] font-mono font-medium ${
                    activePatient.riskClassification === "High" ? "text-rose-400" : "text-amber-400"
                  }`}>
                    {activePatient.riskClassification} Risk
                  </span>
                </div>
              </div>

              {/* Mutations tags */}
              <div className="mt-4 space-y-2">
                <span className="text-[10px] font-mono text-zinc-500 uppercase">Identified Variant Mutations:</span>
                <div className="flex flex-wrap gap-1.5">
                  {activePatient.mutations.map((m, idx) => (
                    <span 
                      key={idx}
                      onClick={() => setView("variant-analysis")}
                      className="px-2.5 py-1 rounded-md bg-purple-950/30 border border-purple-900/40 text-xs font-mono text-purple-300 hover:border-purple-400 transition-colors cursor-pointer"
                    >
                      {m.gene} <span className="text-zinc-500 font-sans">{m.variant}</span>
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {/* Interactive Recharts Data Plots */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Chart A: Tumor Mutational Burden */}
            <div className="glass-panel rounded-2xl p-4 space-y-4">
              <div>
                <h4 className="text-xs font-mono text-purple-400 uppercase tracking-widest">Cohort TMB Comparison</h4>
                <h3 className="text-sm font-display font-medium text-white">Tumor Mutational Burden</h3>
              </div>
              
              <div className="h-52 w-full text-xs font-mono">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={mutationBurdenChartData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorBurden" x1="y" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#a855f7" stopOpacity={0.4}/>
                        <stop offset="95%" stopColor="#a855f7" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="name" stroke="#52525b" />
                    <YAxis stroke="#52525b" />
                    <Tooltip 
                      contentStyle={{ backgroundColor: "#0e071c", borderColor: "#3b82f6" }}
                      labelFormatter={(label) => `COHORT ID: ${label}`}
                    />
                    <Area type="monotone" dataKey="Burden" stroke="#a855f7" fillOpacity={1} fill="url(#colorBurden)" strokeWidth={2} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart B: Driver Variant Sequencing Depth */}
            <div className="glass-panel rounded-2xl p-4 space-y-4">
              <div>
                <h4 className="text-xs font-mono text-pink-400 uppercase tracking-widest">Genomic Read Depth</h4>
                <h3 className="text-sm font-display font-medium text-white">Variant Amplification / Depth</h3>
              </div>

              <div className="h-52 w-full text-xs font-mono">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={pathwayData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                    <XAxis dataKey="name" stroke="#52525b" />
                    <YAxis stroke="#52525b" />
                    <Tooltip 
                      contentStyle={{ backgroundColor: "#0e071c", borderColor: "#a855f7" }}
                    />
                    <Bar dataKey="val" fill="#ec4899" radius={[4, 4, 0, 0]}>
                      {pathwayData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

          </div>

          {/* Quick-links banner to other functional modules */}
          <div className="grid grid-cols-3 gap-3">
            {[
              { title: "Somatic Variant Bench", view: "variant-analysis", text: "Annotate Mutation pathogenicity", desc: "TP53, EGFR, KRAS analysis" },
              { title: "Evolution Sandbox", view: "evolution", text: "Model metastatic clonal resistance", desc: "Clonal drift timeline checks" },
              { title: "Molecular Tumor Board", view: "reports", text: "Compile board report", desc: "AI consultation & PDF" }
            ].map((link, idx) => (
              <div 
                key={idx}
                onClick={() => setView(link.view as ViewState)}
                className="p-3 bg-zinc-950/40 border border-zinc-900 rounded-xl hover:border-purple-500/40 hover:bg-purple-950/10 cursor-pointer transition-all text-left group"
              >
                <div className="text-xs font-display font-medium text-zinc-200 group-hover:text-purple-400 transition-colors">{link.title}</div>
                <div className="text-[10px] text-zinc-500 mt-1 font-mono">{link.desc}</div>
                <div className="text-[9px] text-zinc-400 mt-0.5">{link.text}</div>
              </div>
            ))}
          </div>

        </div>

      </div>
    </div>
  );
}
