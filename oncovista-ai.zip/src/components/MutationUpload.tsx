import React from "react";
import { Patient, Mutation, ViewState } from "../types";
import { Upload, FileText, CheckCircle, Database, AlertCircle, Play, Info } from "lucide-react";
import { motion } from "motion/react";

interface UploadProps {
  patients: Patient[];
  activePatient: Patient | null;
  setActivePatient: (p: Patient) => void;
  onMutationParsed: (muts: Mutation[]) => void;
  setView: (v: ViewState) => void;
}

export default function MutationUpload({ patients, activePatient, setActivePatient, onMutationParsed, setView }: UploadProps) {
  const [dragActive, setDragActive] = React.useState(false);
  const [uploadProgress, setUploadProgress] = React.useState(-1); // -1 = idle
  const [selectedFile, setSelectedFile] = React.useState<File | null>(null);
  const [pastedCode, setPastedCode] = React.useState("");
  const [isVCF, setIsVCF] = React.useState(true);
  const [statusMessage, setStatusMessage] = React.useState("");
  const [selectedTargetPatientId, setSelectedTargetPatientId] = React.useState(activePatient?.id || "");

  // Preset VCF configuration contents for quick developer testing
  const presetVcfSample = `##fileformat=VCFv4.2
##FILTER=<ID=PASS,Description="All filters passed">
##INFO=<ID=GENE,Number=1,Type=String,Description="Genomic target mutational gene label">
#CHROM	POS	ID	REF	ALT	QUAL	FILTER	INFO
chr17	7577538	.	C	T	999	PASS	GENE=TP53;VAF=0.45;DEPTH=880
chr7	5524246	.	G	A	999	PASS	GENE=EGFR;VAF=0.38;DEPTH=920
chr12	2539828	.	C	A	999	PASS	GENE=KRAS;VAF=0.22;DEPTH=540
chr3	1789360	.	A	G	999	PASS	GENE=PIK3CA;VAF=0.18;DEPTH=1210`;

  const presetCsvSample = `Gene,Variant,Pathogenicity,Clinical Significance
BRCA1,C61G,Pathogenic,Disruption of Zn RING domain. Induces homologous recombination deficiency (HRD). Olaparib sensitive.
BRAF,V600E,Pathogenic,Hyperactivates MAPK cycle pathway. Combi Dabrafenib + Trametinib.
TP53,R273H,Pathogenic,Abolishes p53 transcriptional binding. Induces platinum resistance.`;

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setSelectedFile(file);
      setIsVCF(file.name.endsWith(".vcf"));
      readAndProcessFile(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      setIsVCF(file.name.endsWith(".vcf"));
      readAndProcessFile(file);
    }
  };

  const readAndProcessFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setPastedCode(event.target.result as string);
      }
    };
    reader.readAsText(file);
    setStatusMessage(`Loaded File: ${file.name} (${(file.size / 1024).toFixed(1)} KB). Ready for mutation alignment.`);
  };

  const loadPreset = (type: "VCF" | "CSV") => {
    if (type === "VCF") {
      setIsVCF(true);
      setPastedCode(presetVcfSample);
      setStatusMessage("Matched preset Somatic VCF genomic file successfully.");
    } else {
      setIsVCF(false);
      setPastedCode(presetCsvSample);
      setStatusMessage("Matched preset Variant CSV genomic file successfully.");
    }
  };

  const mockTriggerAlignment = async () => {
    if (!pastedCode.trim()) {
      setStatusMessage("Please paste clinical genomic sequence logs or select a preset first.");
      return;
    }

    setUploadProgress(10);
    setStatusMessage("Initializing sequence assembly model parameters...");

    // Animate structural alignment levels
    const intervals = [
      { p: 35, msg: "Aligning genetic sequences against reference Genome GRCh38..." },
      { p: 60, msg: "Measuring Variant Allele Frequency (VAF) and sequencing depths..." },
      { p: 85, msg: "Validating clinical classifications with precision oncology files..." },
      { p: 100, msg: "Alignment complete! Processing molecular annotations..." }
    ];

    for (const step of intervals) {
      await new Promise(r => setTimeout(r, 650));
      setUploadProgress(step.p);
      setStatusMessage(step.msg);
    }

    // Call simulated parser on server
    try {
      const res = await fetch("/api/mutations/upload", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fileName: isVCF ? "genomics_upload.vcf" : "genomics_upload.csv",
          fileContent: pastedCode,
          patientId: selectedTargetPatientId || null
        })
      });

      const data = await res.json();
      if (res.ok) {
        setStatusMessage(data.message);
        if (data.mutations) {
          onMutationParsed(data.mutations);
        }
        // If loaded into a patient, sync patient data
        if (data.patient) {
          // Trigger global patient state updating
          // Wait half second and redirect to Variant dashboard
          setTimeout(() => {
            setView("variant-analysis");
          }, 1200);
        } else {
          // Transient upload, redirect to main variants board to examine
          setTimeout(() => {
            setView("variant-analysis");
          }, 1200);
        }
      } else {
        setStatusMessage(`Alignment failed: ${data.error}`);
      }
    } catch (err: any) {
      setStatusMessage(`Network alignment error: ${err.message}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <div className="text-xs font-mono text-purple-400 uppercase tracking-widest flex items-center gap-2">
          <Database className="w-3.5 h-3.5" />
          Precision Somatic Variant Upload Workspace
        </div>
        <h1 className="text-2xl font-display font-medium text-white tracking-tight mt-1">
          Genomic Sequencing Plate Aligner
        </h1>
        <p className="text-zinc-400 text-xs md:text-sm mt-1 max-w-3xl">
          Upload next-generation sequencing (NGS) oncology reports in standard variant formatting (.VCF) or clinical somatic list matrices (.CSV) to map the driver mutations instantly.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Side 2-Columns: Drag Drop & Input area */}
        <div className="lg:col-span-2 space-y-6">
          
          <div className="glass-panel rounded-2xl p-6 space-y-4">
            
            {/* Target Patient mapping selector */}
            <div className="space-y-2">
              <label className="text-xs font-mono text-zinc-400 uppercase block">Map Sequenced Mutations to Patient Cohort</label>
              <select 
                value={selectedTargetPatientId}
                onChange={(e) => setSelectedTargetPatientId(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-purple-500"
              >
                <option value="">-- Sandbox Mode (Analyze transiently without overriding patient files) --</option>
                {patients.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.id} - {p.name} ({p.diagnosis} · {p.stage})
                  </option>
                ))}
              </select>
            </div>

            {/* Drag & Drop Frame */}
            <div 
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all cursor-pointer flex flex-col items-center justify-center space-y-3 relative ${
                dragActive 
                  ? "border-purple-500 bg-purple-950/15" 
                  : selectedFile 
                    ? "border-emerald-500/50 bg-emerald-950/5" 
                    : "border-zinc-800 hover:border-purple-500/30"
              }`}
            >
              <input 
                type="file"
                id="file-upload-input"
                multiple={false}
                onChange={handleFileChange}
                accept=".vcf,.csv,.txt"
                className="hidden"
              />
              
              <label htmlFor="file-upload-input" className="cursor-pointer flex flex-col items-center">
                <div className={`p-4 rounded-full mb-2 ${selectedFile ? "bg-emerald-500/10 text-emerald-400" : "bg-purple-500/10 text-purple-400"}`}>
                  <Upload className="w-8 h-8" />
                </div>
                <div className="text-sm font-semibold text-zinc-200">
                  {selectedFile ? `Selected ${selectedFile.name}` : "Drag and drop your genomic file here"}
                </div>
                <div className="text-xs text-zinc-500 font-mono mt-1">Supports standard VCFv4.2 panels and genomic CSV variant files</div>
              </label>

              {selectedFile && (
                <div className="text-xs font-mono text-emerald-400 flex items-center gap-1.5 bg-emerald-950/20 px-3 py-1.5 rounded-lg">
                  <CheckCircle className="w-3.5 h-3.5" />
                  File validated successfully ready for biological alignment.
                </div>
              )}
            </div>

            {/* Pasted area */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-mono text-zinc-400 uppercase">Sequencing Log Sequence Core (Raw Text)</label>
                <div className="flex gap-2">
                  <button 
                    onClick={() => loadPreset("VCF")}
                    className="px-2 py-1 text-[9px] font-mono rounded bg-purple-950/40 border border-purple-850 hover:bg-purple-900/40 text-purple-300"
                  >
                    Load VCF Preset
                  </button>
                  <button 
                    onClick={() => loadPreset("CSV")}
                    className="px-2 py-1 text-[10px] font-mono rounded bg-pink-950/40 border border-pink-850 hover:bg-pink-900/40 text-pink-300"
                  >
                    Load CSV Preset
                  </button>
                </div>
              </div>

              <textarea 
                value={pastedCode}
                onChange={(e) => setPastedCode(e.target.value)}
                placeholder="Paste VCF nucleotide sequencing rows or gene matrices..."
                className="w-full h-44 bg-zinc-950/80 border border-zinc-900 rounded-xl p-3 text-xs font-mono text-emerald-400 focus:outline-none focus:border-purple-500 scrollbar"
              />
            </div>

            {/* Align Action Button */}
            <div className="flex items-center justify-between pt-2">
              <span className="text-[10px] text-zinc-500 font-mono flex items-center gap-1">
                <Info className="w-3.5 h-3.5" />
                GRCh38 Reference Genome alignment mapping active
              </span>
              <button 
                onClick={mockTriggerAlignment}
                className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-750 text-xs font-semibold text-white flex items-center gap-1.5 shadow-lg shadow-purple-600/10 hover:scale-105 active:scale-95 transition-transform cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                Execute Somatic Variant Alignment
              </button>
            </div>

          </div>

          {/* Alignment status updates */}
          {uploadProgress >= 0 && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 bg-zinc-950/80 border border-zinc-900 rounded-2xl space-y-3"
            >
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-zinc-400 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-500 animate-ping" />
                  {statusMessage}
                </span>
                <span className="text-purple-400 font-bold">{uploadProgress}%</span>
              </div>
              <div className="w-full bg-zinc-900 rounded-full h-1.5 overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${uploadProgress}%` }}
                  className="bg-gradient-to-r from-neon-purple to-neon-pink h-full"
                />
              </div>
            </motion.div>
          )}

        </div>

        {/* Right Side Column: Clinical Guidelines */}
        <div className="space-y-6">
          <div className="glass-panel rounded-2xl p-5 space-y-4 text-xs">
            <h3 className="text-sm font-display font-medium text-white flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-purple-400" />
              Somatic Upload Standards
            </h3>
            
            <p className="text-zinc-400 leading-relaxed">
              To align variants against precision cancer models, assure files conform to ClinGen standard genomic positions or HGVS mutation nomenclature annotations.
            </p>

            <div className="space-y-3 pt-3 border-t border-zinc-900 font-mono text-[10px]">
              <div>
                <dt className="text-purple-400 font-semibold mb-1">VCF FORMATTING RULES</dt>
                <dd className="text-zinc-500 leading-relaxed ml-2 pl-2 border-l border-zinc-800">
                  Must supply chromosome indices, target mutation position nucleotides, REF allele and ALT sequences. Add `GENE=SYMBOL` tag configurations inside INFO columns to automate targeting.
                </dd>
              </div>

              <div>
                <dt className="text-pink-400 font-semibold mb-1">CSV MATRIX STRUCTURE</dt>
                <dd className="text-zinc-500 leading-relaxed ml-2 pl-2 border-l border-zinc-800">
                  Headers must define: `Gene`, `Variant`, `Pathogenicity`, `Clinical Significance`. E.g., `TP53,R273H,Pathogenic,Apoptosis failure`.
                </dd>
              </div>

              <div>
                <dt className="text-blue-400 font-semibold mb-1">ALIGNMENT TIMELINES</dt>
                <dd className="text-zinc-500 leading-relaxed ml-2 pl-2 border-l border-zinc-800">
                  Alignment assemblies complete in 1.5 - 3 seconds depending on mutations density levels. Live results automatically forward to variant annotator panels.
                </dd>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
