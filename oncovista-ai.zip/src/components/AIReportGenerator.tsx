import React from "react";
import { Patient, ClinicalReportPayload, ViewState } from "../types";
import { Sparkles, BrainCircuit, FileSpreadsheet, FileClock, Printer, ClipboardCopy, FileText, Bookmark, Info } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ReportProps {
  activePatient: Patient | null;
  setView: (v: ViewState) => void;
}

export default function AIReportGenerator({ activePatient, setView }: ReportProps) {
  const [clinicianNotes, setClinicianNotes] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [report, setReport] = React.useState<ClinicalReportPayload | null>(null);
  const [actionMessage, setActionMessage] = React.useState("");
  const [pastedStatus, setPastedStatus] = React.useState(false);

  const fetchReport = async () => {
    if (!activePatient) return;
    setLoading(true);
    setReport(null);
    setActionMessage("");

    try {
      const res = await fetch("/api/reports/generate-clinical", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          patientId: activePatient.id,
          doctorNotes: clinicianNotes
        })
      });

      const data = await res.json();
      if (res.ok) {
        setReport(data.report);
      } else {
        setActionMessage(`Failed to assemble clinical files: ${data.error}`);
      }
    } catch (err: any) {
      setActionMessage(`Network connection error with reporting center: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    if (!report || !activePatient) return;
    const coreText = `
ONCOVISTA AI - CLINICAL GENOMICS CONSULTATION REPORT
===================================================
PATIENT ID: ${activePatient.id}
PATIENT NAME: ${activePatient.name}
DIAGNOSIS: ${activePatient.diagnosis} (${activePatient.stage})
GENOMIC TUMOR BURDEN: ${activePatient.tumorBurden} mut/Mb

EXECUTIVE SUMMARY:
${report.summary}

MOLECULAR PATHOLOGICAL SYNTHESIS:
${report.molecularPathologicalSynthesis}

SUGGESTED PHARMACOLOGICAL RECIPE:
${report.suggestedTherapyRegimen}

RESISTANCE MITIGATION & SURVEILLANCE:
${report.resistanceMitigation}

MATCHED CLINICAL TRIALS:
${report.personalizedClinicalTrialSummary}
===================================================
Generated: ${new Date().toLocaleDateString()} via OncoVista AI.
    `;
    navigator.clipboard.writeText(coreText);
    setPastedStatus(true);
    setTimeout(() => setPastedStatus(false), 2000);
  };

  const triggerPrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <div className="text-xs font-mono text-purple-400 uppercase tracking-widest flex items-center gap-2">
          <FileText className="w-3.5 h-3.5" />
          Oncology Board Decision System
        </div>
        <h1 className="text-2xl font-display font-medium text-white tracking-tight mt-1">
          Precision Diagnostic Reports
        </h1>
        <p className="text-zinc-400 text-xs md:text-sm mt-1 max-w-2xl">
          Instantly compile regulatory-grade molecular tumor board summaries containing pathology annotations, target recipes, drug-escape warning guides, and clinical trial matches.
        </p>
      </div>

      {!activePatient ? (
        <div className="text-center py-16 bg-zinc-950/20 border border-zinc-900 rounded-2xl space-y-4 max-w-md mx-auto">
          <FileClock className="w-12 h-12 text-zinc-650 mx-auto" />
          <h3 className="text-base font-display font-medium text-white">No active patient file selected</h3>
          <p className="text-xs text-zinc-500 max-w-xs mx-auto leading-relaxed">
            Please navigate back to the dashboard roster and select a sequenced genomics patient cases profile first to build reports.
          </p>
          <button 
            onClick={() => setView("dashboard")}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-purple-650 hover:bg-purple-700 text-white cursor-pointer"
          >
            Review Patient Roster
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Notes and action console */}
          <div className="space-y-4">
            
            <div className="glass-panel rounded-2xl p-5 space-y-4">
              <h3 className="text-xs font-mono text-zinc-400 block uppercase">Report Configurator</h3>
              
              <div className="p-3 bg-zinc-950/60 rounded-xl border border-zinc-900 font-mono text-xs text-zinc-400 space-y-1">
                <span className="text-[9px] text-zinc-500 block uppercase">Target Genome Profile</span>
                <div className="text-white font-bold">{activePatient.name}</div>
                <div>ID: {activePatient.id} · Stage: {activePatient.stage}</div>
                <div>Diagnosis: <strong className="text-purple-400">{activePatient.diagnosis}</strong></div>
              </div>

              {/* Notes fields */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-zinc-400 uppercase block">Clinician Directed Guidance (Optional)</label>
                <textarea 
                  value={clinicianNotes}
                  onChange={(e) => setClinicianNotes(e.target.value)}
                  placeholder="Enrich interpretation with custom molecular targets, chemotherapy limits, age considerations, or clinical trials boundaries..."
                  className="w-full h-36 bg-zinc-950/50 border border-zinc-800 rounded-xl p-3 text-xs text-zinc-300 focus:outline-none focus:border-purple-500"
                />
              </div>

              <button 
                onClick={fetchReport}
                disabled={loading}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-neon-purple to-neon-pink text-xs font-semibold text-white cursor-pointer shadow-lg shadow-purple-500/10 hover:opacity-95 flex items-center justify-center gap-1.5 transition-all"
              >
                <Sparkles className="w-4 h-4 text-white animate-pulse" />
                {loading ? "Assembling Clinical Files..." : "Generate AI Advisory Report"}
              </button>

              {actionMessage && (
                <div className="p-3.5 border border-rose-500/10 bg-rose-500/5 text-rose-400 rounded-xl text-xs font-mono text-center">
                  {actionMessage}
                </div>
              )}
            </div>

            <div className="p-4 bg-zinc-950/80 border border-zinc-900 rounded-xl text-[10px] font-mono text-zinc-500 flex items-start gap-2 leading-relaxed">
              <Info className="w-4 h-4 text-purple-400 mt-0.5 shrink-0" />
              <p className="font-sans text-zinc-500">
                Advisory reports combine the patient's individual variant list with server-side AI evaluation guidelines. Standard execution completes in roughly 2-3 seconds.
              </p>
            </div>
          </div>

          {/* AI Output container */}
          <div className="lg:col-span-2">
            
            <AnimatePresence mode="wait">
              {loading && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="py-24 text-center glass-panel rounded-2xl space-y-4"
                >
                  <BrainCircuit className="w-12 h-12 text-purple-400 animate-spin mx-auto" />
                  <div className="space-y-1">
                    <h3 className="text-sm font-display font-semibold text-white">Synthesizing Genomic Evidence Logs</h3>
                    <p className="text-xs text-zinc-500 max-w-xs mx-auto font-mono">
                      Aligning mutational pathogenicity ratios, prognostic median months and tumor board escape mechanisms.
                    </p>
                  </div>
                </motion.div>
              )}

              {!loading && !report && (
                <div className="py-24 text-center glass-panel rounded-2xl border-dashed border-2 border-zinc-900">
                  <FileSpreadsheet className="w-12 h-12 text-zinc-700 mx-auto" />
                  <h3 className="text-sm font-display font-medium text-white mt-3">Interactive Advisory Template Ready</h3>
                  <p className="text-xs text-zinc-500 max-w-xs mx-auto mt-1">
                    Click "Generate AI Advisory Report" inside the options panel to construct full molecular summary charts.
                  </p>
                </div>
              )}

              {!loading && report && (
                <motion.div 
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-6"
                >
                  {/* Action row */}
                  <div className="flex justify-end gap-2 p-1.5 bg-zinc-950/60 border border-zinc-900 rounded-xl text-xs font-mono">
                    <button 
                      onClick={copyToClipboard}
                      className="px-3 py-1.5 rounded-lg text-zinc-300 hover:text-white flex items-center gap-1.5 cursor-pointer bg-zinc-900 border border-zinc-800"
                    >
                      <ClipboardCopy className="w-3.5 h-3.5" />
                      {pastedStatus ? "Copied Raw Text!" : "Copy Raw Text"}
                    </button>
                    <button 
                      onClick={triggerPrint}
                      className="px-3 py-1.5 rounded-lg bg-purple-600 text-white flex items-center gap-1.5 hover:bg-purple-750 cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      Print Formal Report
                    </button>
                  </div>

                  {/* Formal Print Sheet (styled beautifully) */}
                  <div id="oncologi-print-sheet" className="p-8 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-6 text-zinc-300 leading-relaxed font-sans shadow-2xl relative">
                    {/* Header overlay */}
                    <div className="flex items-center justify-between border-b border-zinc-800 pb-5">
                      <div className="space-y-1">
                        <div className="text-xs font-mono uppercase tracking-widest text-purple-400 font-bold flex items-center gap-1">
                          <Bookmark className="w-3.5 h-3.5" />
                          OncoVista AI
                        </div>
                        <h2 className="text-lg font-display font-medium text-white font-bold tracking-tight">Molecular Tumor Board</h2>
                        <span className="text-[10px] text-zinc-500 font-mono">GENOMICS CLINICAL ADVISORY DOCUMENT</span>
                      </div>
                      <div className="text-right font-mono text-[10px] text-zinc-500 space-y-0.5">
                        <div>REF ID: {Math.floor(1000 + Math.random()*9000)}-OVC</div>
                        <div>DATE: {new Date().toLocaleDateString()}</div>
                        <div className="text-purple-400">STATUS: VERIFIED</div>
                      </div>
                    </div>

                    {/* Patient summary boxes */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 border border-zinc-850 rounded-xl bg-zinc-900/40 text-[11px] font-mono">
                      <div>
                        <span className="text-zinc-500 uppercase text-[9px] block">Patient Name</span>
                        <strong className="text-white text-xs">{activePatient.name}</strong>
                      </div>
                      <div>
                        <span className="text-zinc-500 uppercase text-[9px] block">Subject ID</span>
                        <strong className="text-white text-xs">{activePatient.id}</strong>
                      </div>
                      <div>
                        <span className="text-zinc-500 uppercase text-[9px] block">Age / Gender</span>
                        <strong className="text-white text-xs">{activePatient.age}yo / {activePatient.gender}</strong>
                      </div>
                      <div>
                        <span className="text-zinc-500 uppercase text-[9px] block">Primary Diagnosis</span>
                        <strong className="text-purple-400 text-xs truncate block">{activePatient.diagnosis}</strong>
                      </div>
                    </div>

                    {/* Body content blocks */}
                    <div className="space-y-6 font-sans text-xs">
                      
                      <div className="space-y-2">
                        <h4 className="text-[10px] font-mono text-zinc-400 block uppercase font-bold tracking-wider">I. Case Narrative & Executive Summary</h4>
                        <p className="leading-relaxed bg-zinc-900/20 p-4 rounded-xl border border-zinc-850 text-zinc-300">
                          {report.summary}
                        </p>
                      </div>

                      <div className="space-y-2">
                        <h4 className="text-[10px] font-mono text-zinc-400 block uppercase font-bold tracking-wider">II. Molecular Pathological Co-Mutation Synthesis</h4>
                        <p className="leading-relaxed bg-zinc-900/20 p-4 rounded-xl border border-zinc-850 text-zinc-300">
                          {report.molecularPathologicalSynthesis}
                        </p>
                      </div>

                      <div className="space-y-2">
                        <h4 className="text-[10px] font-mono text-zinc-400 block uppercase font-bold tracking-wider">III. Suggested Targeted Pharmacological Regimens</h4>
                        <p className="leading-relaxed bg-zinc-900/20 p-4 rounded-xl border border-zinc-850 text-zinc-300">
                          {report.suggestedTherapyRegimen}
                        </p>
                      </div>

                      <div className="space-y-2">
                        <h4 className="text-[10px] font-mono text-zinc-400 block uppercase font-bold tracking-wider">IV. Somatic Resistance Mitigation & Followup surveillance</h4>
                        <p className="leading-relaxed bg-zinc-900/20 p-4 rounded-xl border border-zinc-850 text-zinc-300">
                          {report.resistanceMitigation}
                        </p>
                      </div>

                      <div className="space-y-2">
                        <h4 className="text-[10px] font-mono text-zinc-400 block uppercase font-bold tracking-wider">V. Customized basket Clinical Trial Matches</h4>
                        <p className="leading-relaxed bg-rose-950/10 p-4 rounded-xl border border-rose-900/30 text-rose-300">
                          {report.personalizedClinicalTrialSummary}
                        </p>
                      </div>

                    </div>

                    {/* Signoff */}
                    <div className="border-t border-zinc-800 pt-6 flex flex-col md:flex-row md:items-center justify-between gap-4 font-mono text-[10px]">
                      <div className="text-zinc-500">
                        * Advisory materials calculated using generative genomic indexes. For investigational matching.
                      </div>
                      
                      <div className="text-[11px] text-zinc-400 flex flex-col items-start md:items-end gap-1 font-sans">
                        <strong className="text-white">ONCOVISTA AI MOLECULAR TUMOR BOARD</strong>
                        <span>Electronic signature active · Verified</span>
                      </div>
                    </div>

                  </div>

                </motion.div>
              )}
            </AnimatePresence>

          </div>

        </div>
      )}
    </div>
  );
}
