// Type Definitions for OncoVista AI Precision Oncology Platform

export interface Mutation {
  gene: string;
  variant: string;
  consequence: string;
  vaf: number; // Variant Allele Frequency
  depth: number;
  pathogenicity: "Pathogenic" | "Likely Pathogenic" | "VUS" | "Benign";
  clinicalSignificance: string;
}

export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: string;
  diagnosis: string;
  stage: string;
  status: "Active" | "Stable" | "Progression" | "Remission";
  tumorBurden: number; // Mut/Mb
  mutations: Mutation[];
  riskScore: number; // 0-100
  riskClassification: "High" | "Intermediate" | "Low";
  createdAt: string;
}

export interface BiomarkerPair {
  gene: string;
  mutation: string;
  agent: string;
  tier: string;
  response: string;
  evidence: string;
}

export interface TCGACohort {
  name: string;
  sampleCount: number;
  driverFreqs: { gene: string; pct: number }[];
}

export interface EvolutionClone {
  name: string;
  fraction: number;
  mutations: string[];
  sensitivity: string;
}

export interface EvolutionPhase {
  timepoint: string;
  clones: EvolutionClone[];
  clonalMetastasisChance: string;
}

export interface MetastaticProjection {
  organ: string;
  probability: number;
}

export interface EvolutionSimulation {
  timelineWeeks: number[];
  treatmentPressure: string;
  clonalPhases: EvolutionPhase[];
  metastaticProjections: MetastaticProjection[];
}

export interface AIInterpretation {
  pathogenicity: string;
  mechanism: string;
  targetedTherapies: string;
  resistanceMarkers: string;
  clinicalTrialSuggestion: string;
  prognosticImpact: string;
  tumorBoardRecommendation: string;
}

export interface ClinicalReportPayload {
  summary: string;
  molecularPathologicalSynthesis: string;
  suggestedTherapyRegimen: string;
  resistanceMitigation: string;
  personalizedClinicalTrialSummary: string;
}

export type ViewState =
  | "landing"
  | "login"
  | "dashboard"
  | "upload"
  | "variant-analysis"
  | "biomarkers"
  | "therapies"
  | "survival"
  | "tcga"
  | "evolution"
  | "reports"
  | "settings";

export interface UserSession {
  email: string;
  name: string;
  role: "Clinician" | "Researcher" | "Admin";
  token: string;
}
